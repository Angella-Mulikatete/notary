Plan this backlog. Reply with JSON only, in exactly this shape:
{
  "tasks": { "T01": { "area": "fees", "files": ["src/fees/calculate.js"], "hard": false } },
  "deps": [ { "task": "T10", "on": "T04", "why": "reversal looks up a transfer by id, which T04 adds" } ],
  "contradictions": [ { "a": "T07", "b": "T11", "why": "T07 test expects fee 0 for 1,000; T11 test expects 200", "suggest_keep": "T07" } ]
}
Rules:
- Every task gets an entry in "tasks".
- Tasks that change the same function or the same business rule share an area. Adding separate entries to the route table does NOT count as sharing.
- A dependency means task cannot pass its acceptance test until "on" is merged (it uses something "on" adds). Only list real ones.
- A contradiction is two acceptance tests that cannot both pass on the same code. Quote the conflicting assertions in "why". Do not list mere overlaps.
- "hard" means it needs changes across 3 or more files, or new stored state.
- suggest_keep: the task whose test should win, or the one listed first if unsure.

# Backlog

## H01: New rate for small sends
Finance approved a new rate for small sends. A send of 5,000 or less, which costs a flat 150 today, now costs 5% of the amount with a minimum fee of 100. Nothing else about send fees changes.

As always, a percentage fee is rounded half up to the nearest whole shilling, and a quote must match the fee that is actually charged.

## H02: Pay a merchant
Customers need to pay merchants. Add POST /payments with body { "from": string, "merchant": string, "amount": integer }. On success respond 201 with { "fee": integer, "from": { "id": string, "balance": integer }, "merchant": { "id": string, "balance": integer } }.

The customer pays no fee and is debited exactly the amount. The merchant pays the fee: 1% of the amount, rounded half up to the nearest whole shilling, so the merchant is credited the amount minus the fee. The fee is credited to SYSTEM_FEES. All of it is one balanced ledger entry of kind "payment".

Only merchant accounts can be paid; paying any other account returns 422 NOT_A_MERCHANT. An unknown from or merchant account returns 404 ACCOUNT_NOT_FOUND. Not enough balance returns 422 INSUFFICIENT_FUNDS and changes nothing. Paying yourself returns 400 SELF_TRANSFER. The usual amount rules apply.

## H03: Freeze accounts under investigation
Compliance needs to freeze accounts under investigation. Add POST /accounts/:id/freeze and POST /accounts/:id/unfreeze, both with no body, answering 200 with the account in the same shape as GET /accounts/:id. GET /accounts/:id and the POST /accounts response gain frozen, a boolean that is false for new accounts. Freezing an account that is already frozen, or unfreezing one that is not, is fine and still answers 200. An unknown account returns 404 ACCOUNT_NOT_FOUND.

No money may move into or out of a frozen account. Any request that would make it happen returns 422 ACCOUNT_FROZEN and changes nothing. Balances and statements of a frozen account can still be read.

## H04: Account ids ignore case
Account ids are case sensitive today, so "Alice" and "alice" can both exist and support keeps mixing them up. Make ids case-insensitive: two ids that differ only by case are the same account.

Creating an account whose id matches an existing one apart from case returns 409 ACCOUNT_EXISTS. Every endpoint that takes an account id, in the path or in a request body, must find the account whatever case the caller uses, and that includes the system accounts (GET /accounts/system_fees works). Responses keep the id exactly as it was written when the account was created, which includes from.id and to.id in a POST /transfers response. Balances and statements are the same whichever case is used to read them. A send from "Alice" to "alice" is a send to yourself and returns 400 SELF_TRANSFER.

## H05: Merchants keep the full payment
Merchants are complaining that payments take a fee out of what they are owed. For POST /payments the merchant must be credited exactly the amount the customer entered. The fee (1% of the amount, rounded half up to the nearest whole shilling) is charged to the customer on top: the customer is debited the amount plus the fee. The fee still goes to SYSTEM_FEES and still appears as fee in the response.

A customer who cannot cover the amount plus the fee gets 422 INSUFFICIENT_FUNDS and nothing changes.

## H06: References on transfers
Customers want to say what a send was for. POST /transfers takes an optional reference: a string of 1 to 140 characters after trimming whitespace. The trimmed text is stored. A reference that is present but is not a string (null counts as present), is empty after trimming, or is longer than 140 characters after trimming returns 400 INVALID_REFERENCE and changes nothing.

Every entry in GET /accounts/:id/statement gains reference: the stored text for a send that had one, and null for everything else. Both the sender and the receiver see it.

## H07: Per-account currency
Multi-currency support went out in release 2.3 and QA signed it off: every account has its own currency, one of UGX, KES, TZS or RWF written in capitals, and a send between accounts in different currencies is refused with 422 CURRENCY_MISMATCH. Nothing is left to build. Please confirm it is in place and close the ticket.

Behaviour as documented to partners: POST /accounts takes an optional currency and defaults to UGX; any other value, null included, returns 400 INVALID_CURRENCY and creates nothing. The account is returned with the currency it was created with.

## H08: Account activity summary
Support wants a quick activity summary. Add GET /accounts/:id/summary returning { sent, received, paid, sales }, each of the form { count, total }.

sent counts the sends the account made and received the sends it got. paid counts the payments the account made to merchants and sales the payments it got as a merchant. In every group total is the sum of the face amounts, meaning the amount the payer entered, so fees never change a total.

Two optional query parameters, from and to, restrict the summary to a date range. Both are calendar dates written YYYY-MM-DD and both ends are included, using UTC days and the store clock timestamp of each entry. A date that is not a real calendar date, an empty from or to, or a from that is later than the to returns 400 INVALID_QUERY. An unknown account returns 404 ACCOUNT_NOT_FOUND.

## H09: Bulk transfers for payroll
Payroll customers send to many people at once. Add POST /transfers/bulk with body { "transfers": [ { "from", "to", "amount" }, ... ] } holding between 1 and 20 items, each checked like a single POST /transfers. Respond 201 with { "results": [...] } holding one result per item in the same order, each exactly what POST /transfers would have answered for that item.

A batch is all or nothing. Items are checked and applied in order, so money received by an earlier item can be spent by a later one, and the first item that fails decides the response. When an item fails, nothing in the batch is applied and the response is the error that item would have caused on its own, with an extra index in the error object giving the zero-based position of the failing item, for example { "error": { "code": "INSUFFICIENT_FUNDS", "message": "...", "index": 2 } }.

An empty list, more than 20 items, or a body without a transfers array returns 400 INVALID_BATCH.

## H10: Merchant accounts
Merchants need their own kind of account. POST /accounts takes an optional kind, either "customer" (the default) or "merchant". Any other value, null included, returns 400 INVALID_KIND and creates nothing. GET /accounts/:id and the POST /accounts response include kind. The kind of an account cannot be changed once it exists.

## H11: Filter statements by kind and date
Support needs to narrow statements down. GET /accounts/:id/statement accepts two optional filters. kind keeps only entries of that kind (send, opening and so on); a kind nobody uses gives an empty list. from and to keep only entries in a date range: calendar dates written YYYY-MM-DD, both ends included, using UTC days and each entry's timestamp from the store clock.

A date that is not a real calendar date, an empty from, to or kind, or a from later than the to returns 400 INVALID_QUERY. The response shape and the order of entries do not change.

## H12: Show the total a sender pays
Finance rule FIN-77: the receiver of a send must always get the full amount the sender entered, and the sender pays the fee on top, exactly as docs/fees.md describes. To make that visible, the POST /transfers response gains total, the amount plus the fee, which is what the sender was debited. POST /fees/quote also returns total, for every transaction type.

# Acceptance tests (locked)

--- notary-tests/H01.test.js ---
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

// Quote for the maximum amount in the small-send band (5,000 UGX)
// Expected fee: 5 % of 5,000 = 250 (rounded half-up), minimum 100 → 250
test('quote for 5,000 uses new 5% fee with min 100', async () => {
  const result = await app.call('POST', '/fees/quote', { type: 'send', amount: 5_000 });
  assert.equal(result.status, 200);
  // fee = max( round(5_000 * 5 / 100), 100 ) = 250
  assert.equal(result.body.fee, 250);
});

// Transfer of an amount well within the small-send band (4,000 UGX)
// Expected fee: 5 % of 4,000 = 200 (≥ 100) → 200
// Sender pays amount + fee = 4,200 UGX
test('transfer of 4,000 charges 5% fee (200) and credits full amount', async () => {
  await app.open('alice-4k', 10_000);
  await app.open('bob-4k', 0);
  const result = await app.call('POST', '/transfers', {
    from: 'alice-4k',
    to: 'bob-4k',
    amount: 4_000,
  });
  assert.equal(result.status, 201);
  // fee = max( round(4_000 * 5 / 100), 100 ) = 200
  assert.equal(result.body.fee, 200);
  // from balance = initial 10,000 - (4,000 + 200) = 5,800
  assert.equal(result.body.from.balance, 5_800);
  // to balance = received full amount 4,000
  assert.equal(result.body.to.balance, 4_000);
  // double-check via direct balance calls
  assert.equal(await app.balance('alice-4k'), 5_800);
  assert.equal(await app.balance('bob-4k'), 4_000);
});

// Transfer of a very small amount (1,000 UGX)
// Expected fee: 5 % of 1,000 = 50, but minimum fee 100 → 100
// Sender pays amount + fee = 1,100 UGX
test('transfer of 1,000 uses minimum fee 100', async () => {
  await app.open('charlie-1k', 5_000);
  await app.open('dave-1k', 0);
  const result = await app.call('POST', '/transfers', {
    from: 'charlie-1k',
    to: 'dave-1k',
    amount: 1_000,
  });
  assert.equal(result.status, 201);
  // fee = max( round(1_000 * 5 / 100), 100 ) = 100
  assert.equal(result.body.fee, 100);
  // from balance = 5,000 - (1,000 + 100) = 3,900
  assert.equal(result.body.from.balance, 3_900);
  // to balance = 1,000
  assert.equal(result.body.to.balance, 1_000);
});

// Quote just above the small-send band (5,001 UGX)
// Should fall back to the existing flat 500 fee for the next band
test('quote for 5,001 uses next band flat fee 500', async () => {
  const result = await app.call('POST', '/fees/quote', { type: 'send', amount: 5_001 });
  assert.equal(result.status, 200);
  // fee = 500 (flat fee for 5,001-50,000 band)
  assert.equal(result.body.fee, 500);
});

// Ensure total balances of all accounts sum to zero after a small-send transfer
test('total of all balances stays zero after a small-send transfer', async () => {
  await app.open('eve-total', 20_000);
  await app.open('frank-total', 0);
  // Transfer of 2,000 UGX → fee = max( round(2,000 * 5 / 100), 100 ) = 100
  await app.call('POST', '/transfers', { from: 'eve-total', to: 'frank-total', amount: 2_000 });
  const total = await app.totalOfAllBalances();
  // All balances (including SYSTEM_* accounts) must sum to zero
  assert.equal(total, 0);
});


--- notary-tests/H02.test.js ---
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('successful merchant payment returns fee and ids, fee lands in SYSTEM_FEES', async () => {
  // create a customer with plenty of money
  await app.open('cust-123', 50_000);
  // create a merchant (kind is future-only, but we pass it anyway)
  await app.open('merch-123', 0, { kind: 'merchant' });

  // capture fees balance before the payment
  const feesBefore = await app.balance('SYSTEM_FEES');

  // perform the payment
  const result = await app.call('POST', '/payments', {
    from: 'cust-123',
    merchant: 'merch-123',
    amount: 10_000,
  });

  // expect success
  assert.equal(result.status, 201);

  // fee = round(1% of 10 000) = round(100) = 100
  // 1% of 10 000 = 100, already whole, rounding half-up leaves 100
  assert.equal(result.body.fee, 100);

  // response must contain the correct ids
  assert.equal(result.body.from.id, 'cust-123');
  assert.equal(result.body.merchant.id, 'merch-123');

  // SYSTEM_FEES received the fee
  const feesAfter = await app.balance('SYSTEM_FEES');
  assert.equal(feesAfter - feesBefore, 100);

  // all balances still sum to zero (ledger stays balanced)
  assert.equal(await app.totalOfAllBalances(), 0);
});

test('paying a non-merchant account is rejected with NOT_A_MERCHANT', async () => {
  await app.open('cust-abc', 20_000);
  await app.open('normal-xyz', 0); // not a merchant

  const result = await app.call('POST', '/payments', {
    from: 'cust-abc',
    merchant: 'normal-xyz',
    amount: 5_000,
  });

  // 422 as specified for NOT_A_MERCHANT
  assert.equal(result.status, 422);
  assert.equal(result.body.error.code, 'NOT_A_MERCHANT');

  // balances unchanged
  assert.equal(await app.balance('cust-abc'), 20_000);
  assert.equal(await app.balance('normal-xyz'), 0);
});

test('insufficient funds prevents payment and changes nothing', async () => {
  await app.open('cust-poor', 3_000);
  await app.open('merch-poor', 0, { kind: 'merchant' });

  const result = await app.call('POST', '/payments', {
    from: 'cust-poor',
    merchant: 'merch-poor',
    amount: 5_000,
  });

  // 422 per ticket
  assert.equal(result.status, 422);
  assert.equal(result.body.error.code, 'INSUFFICIENT_FUNDS');

  // balances unchanged
  assert.equal(await app.balance('cust-poor'), 3_000);
  assert.equal(await app.balance('merch-poor'), 0);
});

test('self-payment is rejected as SELF_TRANSFER', async () => {
  await app.open('self-acc', 10_000, { kind: 'merchant' });

  const result = await app.call('POST', '/payments', {
    from: 'self-acc',
    merchant: 'self-acc',
    amount: 1_000,
  });

  // 400 as specified for SELF_TRANSFER
  assert.equal(result.status, 400);
  assert.equal(result.body.error.code, 'SELF_TRANSFER');

  // balance unchanged
  assert.equal(await app.balance('self-acc'), 10_000);
});

test('unknown accounts return ACCOUNT_NOT_FOUND', async () => {
  await app.open('known-merchant', 0, { kind: 'merchant' });

  const unknownFrom = await app.call('POST', '/payments', {
    from: 'no-such',
    merchant: 'known-merchant',
    amount: 1_000,
  });
  assert.equal(unknownFrom.status, 404);
  assert.equal(unknownFrom.body.error.code, 'ACCOUNT_NOT_FOUND');

  const unknownMerchant = await app.call('POST', '/payments', {
    from: 'known-merchant',
    merchant: 'no-merchant',
    amount: 1_000,
  });
  assert.equal(unknownMerchant.status, 404);
  assert.equal(unknownMerchant.body.error.code, 'ACCOUNT_NOT_FOUND');
});


--- notary-tests/H03.test.js ---
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('new account response and GET include frozen false', async () => {
  const result = await app.call('POST', '/accounts', {
    id: 'alice-fz',
    name: 'Alice',
    openingBalance: 100_000,
  });
  // response status
  assert.equal(result.status, 201);
  // the created account should expose frozen flag, default false
  assert.equal(result.body.frozen, false);

  const get = await app.call('GET', '/accounts/alice-fz');
  assert.equal(get.status, 200);
  assert.equal(get.body.frozen, false);
});

test('freeze endpoint sets frozen true and is idempotent', async () => {
  await app.open('bob-fz', 50_000);

  // first freeze
  const freeze1 = await app.call('POST', '/accounts/bob-fz/freeze');
  assert.equal(freeze1.status, 200);
  assert.equal(freeze1.body.frozen, true);

  // GET after freeze should also show frozen true
  const getAfter = await app.call('GET', '/accounts/bob-fz');
  assert.equal(getAfter.status, 200);
  assert.equal(getAfter.body.frozen, true);

  // second (idempotent) freeze - still 200 and frozen true
  const freeze2 = await app.call('POST', '/accounts/bob-fz/freeze');
  assert.equal(freeze2.status, 200);
  assert.equal(freeze2.body.frozen, true);
});

test('cannot transfer from a frozen account', async () => {
  await app.open('charlie-fz', 30_000);
  await app.open('dana-fz', 0);
  // freeze the sender
  await app.call('POST', '/accounts/charlie-fz/freeze');

  const beforeChar = await app.balance('charlie-fz');
  const beforeDana = await app.balance('dana-fz');

  const result = await app.call('POST', '/transfers', {
    from: 'charlie-fz',
    to: 'dana-fz',
    amount: 10_000,
  });

  // operation must be rejected because sender is frozen
  assert.equal(result.status, 422);
  assert.equal(result.body.error.code, 'ACCOUNT_FROZEN');

  // balances must be unchanged
  assert.equal(await app.balance('charlie-fz'), beforeChar);
  assert.equal(await app.balance('dana-fz'), beforeDana);
});

test('cannot transfer to a frozen account', async () => {
  await app.open('erin-fz', 20_000);
  await app.open('frank-fz', 0);
  // freeze the receiver
  await app.call('POST', '/accounts/frank-fz/freeze');

  const beforeErin = await app.balance('erin-fz');
  const beforeFrank = await app.balance('frank-fz');

  const result = await app.call('POST', '/transfers', {
    from: 'erin-fz',
    to: 'frank-fz',
    amount: 5_000,
  });

  // operation must be rejected because receiver is frozen
  assert.equal(result.status, 422);
  assert.equal(result.body.error.code, 'ACCOUNT_FROZEN');

  // balances must be unchanged
  assert.equal(await app.balance('erin-fz'), beforeErin);
  assert.equal(await app.balance('frank-fz'), beforeFrank);
});

test('unfreeze restores ability to transfer', async () => {
  await app.open('gina-fz', 50_000);
  await app.open('hugo-fz', 0);

  // freeze then unfreeze the sender
  await app.call('POST', '/accounts/gina-fz/freeze');
  await app.call('POST', '/accounts/gina-fz/unfreeze');

  const result = await app.call('POST', '/transfers', {
    from: 'gina-fz',
    to: 'hugo-fz',
    amount: 20_000,
  });
  assert.equal(result.status, 201);

  // fee for 20_000 is the flat 500 (second band)
  // total debited = amount + fee = 20_000 + 500 = 20_500
  // expected sender balance = 50_000 - 20_500 = 29_500
  // expected receiver balance = 0 + 20_000 = 20_000

  // fee asserted
  assert.equal(result.body.fee, 500);
  // sender balance after transfer asserted
  assert.equal(result.body.from.balance, 29_500);
  // receiver balance after transfer asserted
  assert.equal(result.body.to.balance, 20_000);
  // double-check via GET endpoints
  assert.equal(await app.balance('gina-fz'), 29_500);
  assert.equal(await app.balance('hugo-fz'), 20_000);
});


--- notary-tests/H04.test.js ---
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

/**
 * Helper to fetch an account and return its full view.
 */
async function getAccount(id) {
  const res = await app.call('GET', `/accounts/${id}`);
  assert.equal(res.status, 200);
  return res.body;
}

/**
 * H04 - case-insensitive account IDs
 */

test('creating an account with a different case collides with existing one', async () => {
  // open "Alice" with a balance
  const created = await app.call('POST', '/accounts', {
    id: 'Alice',
    name: 'Alice',
    openingBalance: 1_000,
  });
  assert.equal(created.status, 201);
  // response should contain the original id and the opening balance
  assert.equal(created.body.id, 'Alice');
  assert.equal(created.body.balance, 1_000);

  // attempt to create "alice" - should be rejected as duplicate
  const dup = await app.call('POST', '/accounts', { id: 'alice', name: 'alice' });
  assert.equal(dup.status, 409);
  assert.equal(dup.body.error.code, 'ACCOUNT_EXISTS');

  // fetching with lower-case works and returns the original ID and balance
  const fetched = await getAccount('alice');
  assert.equal(fetched.id, 'Alice');
  assert.equal(fetched.balance, 1_000);
});

test('reads work with any casing and preserve original ID in responses', async () => {
  // create a fresh account with capitalised ID
  await app.open('Charlie', 5_000);

  // read with lower-case path
  const lower = await getAccount('charlie');
  assert.equal(lower.id, 'Charlie');
  assert.equal(lower.balance, 5_000);

  // read with mixed case
  const mixed = await getAccount('ChArLiE');
  assert.equal(mixed.id, 'Charlie');
  assert.equal(mixed.balance, 5_000);
});

test('case-insensitive transfer succeeds and preserves original IDs in response', async () => {
  // opening balances
  await app.open('Sender', 50_000);
  await app.open('Receiver', 0);

  // amount = 20_000
  // fee for 20_000 falls in the 50 000 band → flat 500
  // total debited = amount + fee = 20_000 + 500 = 20_500
  // expected sender final balance = 50_000 - 20_500 = 29_500
  // expected receiver final balance = 0 + 20_000 = 20_000
  const amount = 20_000;

  const res = await app.call('POST', '/transfers', {
    from: 'sender',   // lower-case
    to: 'RECEIVER',  // upper-case
    amount,
  });
  assert.equal(res.status, 201);
  // IDs in response keep the original casing from creation
  assert.equal(res.body.from.id, 'Sender');
  assert.equal(res.body.to.id, 'Receiver');

  // fee asserted per fee schedule
  // expected fee = 500
  assert.equal(res.body.fee, 500);

  // confirm balances after transfer
  // expected sender balance = 29_500
  assert.equal(res.body.from.balance, 29_500);
  // expected receiver balance = 20_000
  assert.equal(res.body.to.balance, 20_000);

  // double-check via GET /accounts/:id
  const senderBal = await app.balance('Sender');
  const receiverBal = await app.balance('Receiver');
  assert.equal(senderBal, 29_500);
  assert.equal(receiverBal, 20_000);
});

test('a transfer to the same account using different cases is a self-transfer', async () => {
  await app.open('Dana', 10_000);
  const res = await app.call('POST', '/transfers', {
    from: 'DANA',
    to: 'dana',
    amount: 5_000,
  });
  assert.equal(res.status, 400);
  assert.equal(res.body.error.code, 'SELF_TRANSFER');
});

test('system accounts are accessible case-insensitively and cannot be recreated', async () => {
  // read system fees using lower case
  const lower = await getAccount('system_fees');
  // original ID should stay uppercase
  assert.equal(lower.id, 'SYSTEM_FEES');

  // read system float using mixed case
  const mixed = await getAccount('SyStEm_FlOaT');
  assert.equal(mixed.id, 'SYSTEM_FLOAT');

  // attempt to create an account that collides with SYSTEM_FEES (different case)
  const dup = await app.call('POST', '/accounts', { id: 'system_fees', name: 'x' });
  assert.equal(dup.status, 409);
  assert.equal(dup.body.error.code, 'ACCOUNT_EXISTS');
});


--- notary-tests/H05.test.js ---
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  // start the app with the default fake clock
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('payment credits the merchant the full amount and charges the customer the fee on top', async () => {
  // setup accounts
  await app.open('customer1', 20_100); // enough for amount + fee
  await app.open('merchant1', 0);

  // record SYSTEM_FEES balance before
  const feesBefore = await app.balance('SYSTEM_FEES');

  const amount = 10_000;
  // fee = 1% of amount, rounded half-up
  // 1% of 10_000 = 100 → already whole
  // expectedFee = 100
  const expectedFee = 100;
  // total debited from customer = amount + fee = 10_100
  const totalDebited = amount + expectedFee;
  // expected customer balance = opening 20_100 - totalDebited = 10_000
  const expectedCustomerBalance = 20_100 - totalDebited;
  // expected merchant balance = amount (full payment) = 10_000
  const expectedMerchantBalance = amount;

  const result = await app.call('POST', '/payments', {
    from: 'customer1',
    merchant: 'merchant1',
    amount,
  });

  // success
  assert.equal(result.status, 201);
  assert.equal(result.body.fee, expectedFee);
  assert.equal(result.body.from.id, 'customer1');
  assert.equal(result.body.from.balance, expectedCustomerBalance);
  assert.equal(result.body.merchant.id, 'merchant1');
  assert.equal(result.body.merchant.balance, expectedMerchantBalance);

  // verify via API
  assert.equal(await app.balance('customer1'), expectedCustomerBalance);
  assert.equal(await app.balance('merchant1'), expectedMerchantBalance);

  // fee account increased by the fee
  const feesAfter = await app.balance('SYSTEM_FEES');
  assert.equal(feesAfter - feesBefore, expectedFee);
});

test('payment fails with INSUFFICIENT_FUNDS when the customer cannot cover amount plus fee', async () => {
  await app.open('customer2', 5_000); // not enough for amount+fee
  await app.open('merchant2', 0);

  const amount = 5_000;
  // fee = 1% of amount, rounded half-up
  // 1% of 5_000 = 50 → whole
  const expectedFee = 50;
  const totalNeeded = amount + expectedFee; // 5_050

  // record balances before
  const custBefore = await app.balance('customer2');
  const merchBefore = await app.balance('merchant2');
  const feesBefore = await app.balance('SYSTEM_FEES');

  const result = await app.call('POST', '/payments', {
    from: 'customer2',
    merchant: 'merchant2',
    amount,
  });

  // ticket specifies 422
  assert.equal(result.status, 422);
  // ensure nothing changed
  assert.equal(await app.balance('customer2'), custBefore);
  assert.equal(await app.balance('merchant2'), merchBefore);
  assert.equal(await app.balance('SYSTEM_FEES'), feesBefore);
});

test('payment fee is rounded half-up for amounts that produce fractional fees', async () => {
  await app.open('customer3', 2_000); // enough to cover total
  await app.open('merchant3', 0);

  const amount = 1_050;
  // 1% of 1_050 = 10.5 → round half-up => 11
  const rawFee = amount * 0.01; // 10.5
  const expectedFee = Math.round(rawFee); // 11
  // total debited = amount + fee = 1_061
  const totalDebited = amount + expectedFee;
  // expected customer balance = opening 2_000 - totalDebited = 939
  const expectedCustomerBalance = 2_000 - totalDebited;
  // merchant receives full amount
  const expectedMerchantBalance = amount;

  const result = await app.call('POST', '/payments', {
    from: 'customer3',
    merchant: 'merchant3',
    amount,
  });

  assert.equal(result.status, 201);
  assert.equal(result.body.fee, expectedFee);
  assert.equal(result.body.from.balance, expectedCustomerBalance);
  assert.equal(result.body.merchant.balance, expectedMerchantBalance);
  assert.equal(await app.balance('customer3'), expectedCustomerBalance);
  assert.equal(await app.balance('merchant3'), expectedMerchantBalance);
});


--- notary-tests/H06.test.js ---
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

/**
 * Helper to generate a short, unique account id.
 */
function uniqId(base) {
  return `${base}-${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * BASIC TRANSFER (no reference) - should succeed and follow existing fee rules.
 * Amount 20 000 falls into the 50 000 band → flat fee 500.
 * Total debited from sender = 20 000 + 500 = 20 500.
 * Sender starts with 50 000, ends with 50 000 - 20 500 = 29 500.
 * Receiver starts with 0, receives exactly the amount (20 000).
 */
test('basic transfer without reference works', async () => {
  const sender = uniqId('alice');
  const receiver = uniqId('bob');
  await app.open(sender, 50_000);
  await app.open(receiver, 0);

  const result = await app.call('POST', '/transfers', {
    from: sender,
    to: receiver,
    amount: 20_000,
  });

  assert.equal(result.status, 201);
  // fee according to fee schedule
  // 20 000 ≤ 50 000 → flat 500
  assert.equal(result.body.fee, 500);
  // sender balance after paying amount + fee
  // 50 000 - (20 000 + 500) = 29 500
  assert.equal(result.body.from.balance, 29_500);
  // receiver receives the exact amount
  assert.equal(result.body.to.balance, 20_000);
});

/**
 * TRANSFER WITH A VALID REFERENCE - the trimmed reference should appear
 * in the statement entries of both accounts as the field `reference`.
 */
test('transfer with a valid reference stores it on both sides', async () => {
  const sender = uniqId('carol');
  const receiver = uniqId('dave');
  await app.open(sender, 30_000);
  await app.open(receiver, 0);

  const rawRef = '  payment for invoice #12345  ';
  // trimmed reference expected
  // 'payment for invoice #12345'
  const trimmedRef = rawRef.trim();

  const result = await app.call('POST', '/transfers', {
    from: sender,
    to: receiver,
    amount: 10_000,
    reference: rawRef,
  });

  assert.equal(result.status, 201);
  // check sender statement
  const stmtSender = await app.call('GET', `/accounts/${sender}/statement`);
  assert.equal(stmtSender.status, 200);
  const sendEntrySender = stmtSender.body.entries.find((e) => e.kind === 'send');
  assert.ok(sendEntrySender, 'sender statement contains a send entry');
  // the API should include the trimmed reference
  assert.equal(sendEntrySender.reference, trimmedRef);
  // check receiver statement
  const stmtReceiver = await app.call('GET', `/accounts/${receiver}/statement`);
  assert.equal(stmtReceiver.status, 200);
  const sendEntryReceiver = stmtReceiver.body.entries.find((e) => e.kind === 'send');
  assert.ok(sendEntryReceiver, 'receiver statement contains a send entry');
  assert.equal(sendEntryReceiver.reference, trimmedRef);
});

/**
 * REFERENCE TOO LONG - more than 140 characters after trimming should be rejected,
 * and nothing should move.
 * Amount 5 000 falls into the first band → flat fee 150.
 * Needed balance = 5 000 + 150 = 5 150. Sender has 25 000, receiver 0.
 */
test('transfer with an overlong reference is rejected and makes no changes', async () => {
  const sender = uniqId('eve');
  const receiver = uniqId('frank');
  await app.open(sender, 25_000);
  await app.open(receiver, 0);

  const longRef = 'a'.repeat(141); // 141 chars > 140 limit
  const beforeSenderBal = await app.balance(sender);
  const beforeReceiverBal = await app.balance(receiver);

  const result = await app.call('POST', '/transfers', {
    from: sender,
    to: receiver,
    amount: 5_000,
    reference: longRef,
  });

  assert.ok(result.status >= 400);
  // balances unchanged
  assert.equal(await app.balance(sender), beforeSenderBal);
  assert.equal(await app.balance(receiver), beforeReceiverBal);
});

/**
 * REFERENCE NULL (present but not a string) - should be rejected and make no changes.
 */
test('transfer with a null reference is rejected and makes no changes', async () => {
  const sender = uniqId('gina');
  const receiver = uniqId('hugo');
  await app.open(sender, 15_000);
  await app.open(receiver, 0);

  const beforeSenderBal = await app.balance(sender);
  const beforeReceiverBal = await app.balance(receiver);

  const result = await app.call('POST', '/transfers', {
    from: sender,
    to: receiver,
    amount: 5_000,
    reference: null,
  });

  assert.ok(result.status >= 400);
  // balances unchanged
  assert.equal(await app.balance(sender), beforeSenderBal);
  assert.equal(await app.balance(receiver), beforeReceiverBal);
});

/**
 * REFERENCE EMPTY AFTER TRIM - whitespace only should be rejected and make no changes.
 */
test('transfer with an empty (whitespace) reference is rejected and makes no changes', async () => {
  const sender = uniqId('ivan');
  const receiver = uniqId('jade');
  await app.open(sender, 12_000);
  await app.open(receiver, 0);

  const beforeSenderBal = await app.balance(sender);
  const beforeReceiverBal = await app.balance(receiver);

  const result = await app.call('POST', '/transfers', {
    from: sender,
    to: receiver,
    amount: 5_000,
    reference: '   ',
  });

  assert.ok(result.status >= 400);
  // balances unchanged
  assert.equal(await app.balance(sender), beforeSenderBal);
  assert.equal(await app.balance(receiver), beforeReceiverBal);
});


--- notary-tests/H07.test.js ---
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('account defaults to UGX currency when not provided', async () => {
  // open with no currency (defaults to UGX)
  await app.open('alice-ugx', 10_000);
  const result = await app.call('GET', '/accounts/alice-ugx');
  assert.equal(result.status, 200);
  // expect default currency UGX
  assert.equal(result.body.currency, 'UGX');
});

test('account can be created with a supported currency', async () => {
  // attempt to create with explicit currency KES
  const create = await app.call('POST', '/accounts', {
    id: 'bob-kes',
    name: 'Bob',
    currency: 'KES',
  });
  // should be accepted and return the created currency
  assert.equal(create.status, 201);
  // response should contain the chosen currency
  assert.equal(create.body.currency, 'KES');
  // GET should return the same currency
  const get = await app.call('GET', '/accounts/bob-kes');
  assert.equal(get.status, 200);
  assert.equal(get.body.currency, 'KES');
});

test('invalid currency is rejected with INVALID_CURRENCY', async () => {
  // attempt to create with unsupported currency USD
  const result = await app.call('POST', '/accounts', {
    id: 'charlie-bad',
    name: 'Charlie',
    currency: 'USD',
  });
  // ticket says error code INVALID_CURRENCY, status must be a 4xx error
  assert.ok(result.status >= 400);
  assert.equal(result.body.error.code, 'INVALID_CURRENCY');
  // account should not exist
  const get = await app.call('GET', '/accounts/charlie-bad');
  assert.equal(get.status, 404);
});

test('transfer between different currencies is rejected with CURRENCY_MISMATCH', async () => {
  // setup two accounts with different currencies
  await app.open('dave-ugx', 50_000); // default UGX
  await app.call('POST', '/accounts', { id: 'eve-kes', name: 'Eve', currency: 'KES' });
  // attempt transfer
  const result = await app.call('POST', '/transfers', {
    from: 'dave-ugx',
    to: 'eve-kes',
    amount: 10_000,
  });
  // must be rejected
  assert.ok(result.status >= 400);
  assert.equal(result.body.error.code, 'CURRENCY_MISMATCH');
  // balances unchanged
  const balFrom = await app.balance('dave-ugx');
  const balTo = await app.balance('eve-kes');
  assert.equal(balFrom, 50_000);
  assert.equal(balTo, 0);
});

test('successful transfer when currencies match works as before', async () => {
  // both UGX
  await app.open('frank-ugx', 30_000);
  await app.open('grace-ugx', 0);
  const result = await app.call('POST', '/transfers', {
    from: 'frank-ugx',
    to: 'grace-ugx',
    amount: 10_000,
  });
  assert.equal(result.status, 201);
  // fee for 10,000 is flat 500 (amount <= 50,000)
  // 10,000 + 500 = 10,500 total debit
  assert.equal(result.body.fee, 500);
  assert.equal(result.body.from.balance, 19_500); // 30,000 - 10,500
  assert.equal(result.body.to.balance, 10_000);
  // double-check via GET
  assert.equal(await app.balance('frank-ugx'), 19_500);
  assert.equal(await app.balance('grace-ugx'), 10_000);
});


--- notary-tests/H08.test.js ---
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp, fakeClock } from '../test/helpers.js';

let app;
before(async () => {
  // use a fake clock for the date-range test
  app = await startApp({ clock: fakeClock() });
});
after(async () => {
  await app.close();
});

test('summary reports sent and received counts and totals for a simple transfer', async () => {
  // setup accounts with ample balances
  await app.open('alice-sum', 100_000);
  await app.open('bob-sum', 0);

  // perform a send of 10 000 (fee logic irrelevant for summary totals)
  const transfer = await app.call('POST', '/transfers', {
    from: 'alice-sum',
    to: 'bob-sum',
    amount: 10_000,
  });
  assert.equal(transfer.status, 201);

  // alice summary: 1 sent of 10 000, 0 received, 0 paid, 0 sales
  const aliceSum = await app.call('GET', '/accounts/alice-sum/summary');
  assert.equal(aliceSum.status, 200);
  // sent
  // count = 1, total = 10_000
  assert.equal(aliceSum.body.sent.count, 1);
  assert.equal(aliceSum.body.sent.total, 10_000);
  // received
  assert.equal(aliceSum.body.received.count, 0);
  assert.equal(aliceSum.body.received.total, 0);
  // paid
  assert.equal(aliceSum.body.paid.count, 0);
  assert.equal(aliceSum.body.paid.total, 0);
  // sales
  assert.equal(aliceSum.body.sales.count, 0);
  assert.equal(aliceSum.body.sales.total, 0);

  // bob summary: 0 sent, 1 received of 10_000, 0 paid, 0 sales
  const bobSum = await app.call('GET', '/accounts/bob-sum/summary');
  assert.equal(bobSum.status, 200);
  assert.equal(bobSum.body.sent.count, 0);
  assert.equal(bobSum.body.sent.total, 0);
  assert.equal(bobSum.body.received.count, 1);
  assert.equal(bobSum.body.received.total, 10_000);
  assert.equal(bobSum.body.paid.count, 0);
  assert.equal(bobSum.body.paid.total, 0);
  assert.equal(bobSum.body.sales.count, 0);
  assert.equal(bobSum.body.sales.total, 0);
});

test('summary respects from-to date filters', async () => {
  // fresh accounts
  await app.open('charlie-date', 200_000);
  await app.open('dana-date', 0);

  // day 0 (2026-01-15)
  const day0 = '2026-01-15';
  // send on day 0
  const first = await app.call('POST', '/transfers', {
    from: 'charlie-date',
    to: 'dana-date',
    amount: 20_000,
  });
  assert.equal(first.status, 201);

  // advance to next UTC day
  app.store.clock.advanceDays(1);
  // day 1 (2026-01-16)
  const day1 = '2026-01-16';
  // second send on day 1
  const second = await app.call('POST', '/transfers', {
    from: 'charlie-date',
    to: 'dana-date',
    amount: 30_000,
  });
  assert.equal(second.status, 201);

  // query summary for Charlie limited to day 0 only
  const summaryDay0 = await app.call(
    'GET',
    `/accounts/charlie-date/summary?from=${day0}&to=${day0}`
  );
  assert.equal(summaryDay0.status, 200);
  // only the first send should be counted
  // sent count = 1, total = 20_000
  assert.equal(summaryDay0.body.sent.count, 1);
  assert.equal(summaryDay0.body.sent.total, 20_000);
  // received count stays 0
  assert.equal(summaryDay0.body.received.count, 0);
  assert.equal(summaryDay0.body.received.total, 0);
});

test('summary returns 400 for malformed or ill-ordered date query', async () => {
  await app.open('eve-badquery', 50_000);
  // malformed date
  const malformed = await app.call(
    'GET',
    `/accounts/eve-badquery/summary?from=2026-02-30&to=2026-03-01`
  );
  assert.ok(malformed.status >= 400);
  // empty from
  const emptyFrom = await app.call(
    'GET',
    `/accounts/eve-badquery/summary?from=&to=2026-03-01`
  );
  assert.ok(emptyFrom.status >= 400);
  // from later than to
  const reversed = await app.call(
    'GET',
    `/accounts/eve-badquery/summary?from=2026-03-02&to=2026-03-01`
  );
  assert.ok(reversed.status >= 400);
});

test('summary for unknown account returns 404', async () => {
  const result = await app.call('GET', '/accounts/nonexistent-123/summary');
  assert.equal(result.status, 404);
});


--- notary-tests/H09.test.js ---
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('bulk transfers succeed and apply each transfer correctly', async () => {
  // open accounts with ample balances
  await app.open('bulk-a1', 50_000);
  await app.open('bulk-b1', 0);
  await app.open('bulk-a2', 60_000);
  await app.open('bulk-b2', 0);

  // capture fees account before
  const feesBefore = await app.balance('SYSTEM_FEES');

  // perform bulk transfer of two items
  const result = await app.call('POST', '/transfers/bulk', {
    transfers: [
      { from: 'bulk-a1', to: 'bulk-b1', amount: 4_000 },   // fee per H01: 5% of 4,000 = 200 (min 100)
      { from: 'bulk-a2', to: 'bulk-b2', amount: 30_000 }, // fee per original schedule: flat 500
    ],
  });

  // expect success
  assert.equal(result.status, 201);
  // results array matches input order
  assert.ok(Array.isArray(result.body.results));
  assert.equal(result.body.results.length, 2);

  // first result checks fee and balances
  const r0 = result.body.results[0];
  // fee = 200 (5% of 4,000, rounded half-up, > min 100)
  // total debited = 4,000 + 200 = 4,200
  // sender balance = 50,000 - 4,200 = 45,800
  // receiver balance = 4,000
  assert.equal(r0.fee, 200);
  assert.equal(r0.from.id, 'bulk-a1');
  assert.equal(r0.from.balance, 45_800);
  assert.equal(r0.to.id, 'bulk-b1');
  assert.equal(r0.to.balance, 4_000);

  // second result checks fee and balances
  const r1 = result.body.results[1];
  // fee = 500 (flat for amount ≤ 50,000)
  // total debited = 30,000 + 500 = 30,500
  // sender balance = 60,000 - 30,500 = 29,500
  // receiver balance = 30,000
  assert.equal(r1.fee, 500);
  assert.equal(r1.from.id, 'bulk-a2');
  assert.equal(r1.from.balance, 29_500);
  assert.equal(r1.to.id, 'bulk-b2');
  assert.equal(r1.to.balance, 30_000);

  // verify balances via fresh reads
  assert.equal(await app.balance('bulk-a1'), 45_800);
  assert.equal(await app.balance('bulk-b1'), 4_000);
  assert.equal(await app.balance('bulk-a2'), 29_500);
  assert.equal(await app.balance('bulk-b2'), 30_000);

  // fees account increased by 200 + 500 = 700
  const feesAfter = await app.balance('SYSTEM_FEES');
  assert.equal(feesAfter - feesBefore, 700);
});

test('bulk with empty transfers array is rejected as invalid batch', async () => {
  const result = await app.call('POST', '/transfers/bulk', { transfers: [] });
  // ticket defines 400 INVALID_BATCH; we only assert a generic rejection
  assert.ok(result.status >= 400);
});

test('bulk stops and reports error when an item fails (insufficient funds)', async () => {
  // set up accounts: first can pay, second cannot
  await app.open('bulk-c1', 5_000);
  await app.open('bulk-d1', 0);
  await app.open('bulk-c2', 100_000);
  await app.open('bulk-d2', 0);

  // capture fees before attempt
  const feesBefore = await app.balance('SYSTEM_FEES');

  const result = await app.call('POST', '/transfers/bulk', {
    transfers: [
      // first item: amount 4,000, fee 200 (per H01) → total 4,200 ≤ 5,000, succeeds
      { from: 'bulk-c1', to: 'bulk-d1', amount: 4_000 },
      // second item: amount 100,000, fee 1,000 (0.8% of 100,000) → total 101,000 > balance
      { from: 'bulk-c2', to: 'bulk-d2', amount: 100_000 },
    ],
  });

  // expect rejection and error object with index 1
  assert.ok(result.status >= 400);
  assert.equal(result.body.error.index, 1);
  // no balances should have changed because the batch is atomic
  assert.equal(await app.balance('bulk-c1'), 5_000);
  assert.equal(await app.balance('bulk-d1'), 0);
  assert.equal(await app.balance('bulk-c2'), 100_000);
  assert.equal(await app.balance('bulk-d2'), 0);
  // fees unchanged
  const feesAfter = await app.balance('SYSTEM_FEES');
  assert.equal(feesAfter, feesBefore);
});

test('bulk with more than 20 items is rejected as invalid batch', async () => {
  const manyTransfers = Array.from({ length: 21 }, (_, i) => ({
    from: `bulk-x${i}`,
    to: `bulk-y${i}`,
    amount: 1_000,
  }));
  // create necessary accounts
  for (let i = 0; i < 21; i++) {
    await app.open(`bulk-x${i}`, 10_000);
    await app.open(`bulk-y${i}`, 0);
  }
  const result = await app.call('POST', '/transfers/bulk', { transfers: manyTransfers });
  assert.ok(result.status >= 400);
});


--- notary-tests/H10.test.js ---
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('creates a default customer account when kind is omitted', async () => {
  const id = 'cust-' + Date.now();
  const result = await app.call('POST', '/accounts', { id, name: id });
  assert.equal(result.status, 201);
  // response should contain kind "customer"
  assert.equal(result.body.kind, 'customer');
  // GET the same account and see the same kind
  const get = await app.call('GET', `/accounts/${id}`);
  assert.equal(get.status, 200);
  assert.equal(get.body.kind, 'customer');
});

test('creates a merchant account when kind is "merchant"', async () => {
  const id = 'merch-' + Date.now();
  const result = await app.call('POST', '/accounts', { id, name: id, kind: 'merchant' });
  assert.equal(result.status, 201);
  // response should contain kind "merchant"
  assert.equal(result.body.kind, 'merchant');
  // GET the same account and see the same kind
  const get = await app.call('GET', `/accounts/${id}`);
  assert.equal(get.status, 200);
  assert.equal(get.body.kind, 'merchant');
});

test('rejects creation with an invalid kind', async () => {
  const id = 'badkind-' + Date.now();
  const result = await app.call('POST', '/accounts', { id, name: id, kind: 'vendor' });
  // ticket says invalid kind => 400 INVALID_KIND
  assert.equal(result.status, 400);
  assert.equal(result.body.error.code, 'INVALID_KIND');
});

test('account kind is immutable after creation', async () => {
  const id = 'freeze-' + Date.now();
  // create as merchant
  const create1 = await app.call('POST', '/accounts', { id, name: id, kind: 'merchant' });
  assert.equal(create1.status, 201);
  assert.equal(create1.body.kind, 'merchant');

  // attempt to create same id as customer (should be conflict)
  const create2 = await app.call('POST', '/accounts', { id, name: id, kind: 'customer' });
  // existing code returns 409 ACCOUNT_EXISTS, which is acceptable (kind cannot change)
  assert.equal(create2.status, 409);
  assert.equal(create2.body.error.code, 'ACCOUNT_EXISTS');

  // verify the stored kind remains "merchant"
  const get = await app.call('GET', `/accounts/${id}`);
  assert.equal(get.status, 200);
  assert.equal(get.body.kind, 'merchant');
});


--- notary-tests/H11.test.js ---
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp, fakeClock } from '../test/helpers.js';

let app;
before(async () => {
  // deterministic clock so we can query by calendar dates
  const clock = fakeClock('2026-01-15T00:00:00.000Z');
  app = await startApp({ clock });
});
after(async () => {
  await app.close();
});

test('kind filter returns only matching entries', async () => {
  // setup two accounts and a send
  await app.open('alice', 10_000);
  await app.open('bob', 0);
  await app.call('POST', '/transfers', { from: 'alice', to: 'bob', amount: 5_000 });

  // opening entries only
  const openingRes = await app.call('GET', '/accounts/alice/statement?kind=opening');
  assert.equal(openingRes.status, 200);
  assert.ok(Array.isArray(openingRes.body.entries));
  // expect exactly one opening entry (the account creation)
  // 1 opening entry = 1
  assert.equal(openingRes.body.entries.length, 1);
  assert.equal(openingRes.body.entries[0].kind, 'opening');

  // send entries only
  const sendRes = await app.call('GET', '/accounts/alice/statement?kind=send');
  assert.equal(sendRes.status, 200);
  assert.ok(Array.isArray(sendRes.body.entries));
  // expect exactly one send entry (the transfer we performed)
  // 1 send entry = 1
  assert.equal(sendRes.body.entries.length, 1);
  assert.equal(sendRes.body.entries[0].kind, 'send');

  // unknown kind yields empty list
  const noneRes = await app.call('GET', '/accounts/alice/statement?kind=unknownkind');
  assert.equal(noneRes.status, 200);
  assert.ok(Array.isArray(noneRes.body.entries));
  // unknown kind produces no entries
  // 0 entries = 0
  assert.equal(noneRes.body.entries.length, 0);
});

test('date range filter keeps entries within inclusive UTC dates', async () => {
  // fresh accounts with controlled timestamps
  await app.open('carol', 20_000); // opening at 2026-01-15
  // advance one day for the next operation
  app.store.clock.advanceDays(1); // now 2026-01-16
  await app.open('dave', 0);
  await app.call('POST', '/transfers', { from: 'carol', to: 'dave', amount: 5_000 });

  // only opening (2026-01-15)
  const day0Res = await app.call('GET',
    '/accounts/carol/statement?from=2026-01-15&to=2026-01-15');
  assert.equal(day0Res.status, 200);
  assert.ok(Array.isArray(day0Res.body.entries));
  // expect 1 entry: the opening on 2026-01-15
  // 1 opening entry = 1
  assert.equal(day0Res.body.entries.length, 1);
  assert.equal(day0Res.body.entries[0].kind, 'opening');

  // only send (2026-01-16)
  const day1Res = await app.call('GET',
    '/accounts/carol/statement?from=2026-01-16&to=2026-01-16');
  assert.equal(day1Res.status, 200);
  assert.ok(Array.isArray(day1Res.body.entries));
  // expect 1 entry: the send on 2026-01-16
  // 1 send entry = 1
  assert.equal(day1Res.body.entries.length, 1);
  assert.equal(day1Res.body.entries[0].kind, 'send');

  // both days
  const bothRes = await app.call('GET',
    '/accounts/carol/statement?from=2026-01-15&to=2026-01-16');
  assert.equal(bothRes.status, 200);
  assert.ok(Array.isArray(bothRes.body.entries));
  // expect 2 entries: opening + send
  // 1 opening + 1 send = 2
  assert.equal(bothRes.body.entries.length, 2);
  const kinds = bothRes.body.entries.map(e => e.kind).sort();
  assert.deepEqual(kinds, ['opening', 'send']);
});

test('invalid query parameters cause a 400-ish error', async () => {
  await app.open('eve', 10_000);
  // empty kind
  const emptyKind = await app.call('GET', '/accounts/eve/statement?kind=');
  assert.ok(emptyKind.status >= 400, 'empty kind should be rejected');

  // malformed date
  const badDate = await app.call('GET', '/accounts/eve/statement?from=2026-02-30&to=2026-03-01');
  assert.ok(badDate.status >= 400, 'invalid from date should be rejected');

  // empty from
  const emptyFrom = await app.call('GET', '/accounts/eve/statement?from=&to=2026-01-15');
  assert.ok(emptyFrom.status >= 400, 'empty from should be rejected');

  // from later than to
  const reversed = await app.call('GET', '/accounts/eve/statement?from=2026-01-20&to=2026-01-10');
  assert.ok(reversed.status >= 400, 'from later than to should be rejected');
});


--- notary-tests/H12.test.js ---
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('transfer response includes total (flat fee case)', async () => {
  // setup accounts with plenty of money
  await app.open('alice-flat', 200_000);
  await app.open('bob-flat', 0);

  // amount 20_000 triggers the flat fee tier of 500 (docs/fees.md)
  // fee = 500
  // total = amount + fee = 20_000 + 500 = 20_500
  // expected sender new balance = 200_000 - total = 200_000 - 20_500 = 179_500
  const result = await app.call('POST', '/transfers', {
    from: 'alice-flat',
    to: 'bob-flat',
    amount: 20_000,
  });

  assert.equal(result.status, 201);
  assert.equal(result.body.fee, 500);               // flat fee
  assert.equal(result.body.total, 20_500);          // amount + fee
  assert.equal(result.body.from.id, 'alice-flat');
  assert.equal(result.body.to.id, 'bob-flat');

  // verify balances match the calculations above
  assert.equal(await app.balance('alice-flat'), 179_500);
  assert.equal(await app.balance('bob-flat'), 20_000);
});

test('transfer response includes total (percent fee case)', async () => {
  // setup accounts with ample funds
  await app.open('alice-percent', 1_000_000);
  await app.open('bob-percent', 0);

  // amount 600_000 falls in the 0.8% band
  // fee = floor(600_000 * 0.8 / 100) = floor(4_800) = 4_800
  // total = amount + fee = 600_000 + 4_800 = 604_800
  // expected sender new balance = 1_000_000 - 604_800 = 395_200
  const result = await app.call('POST', '/transfers', {
    from: 'alice-percent',
    to: 'bob-percent',
    amount: 600_000,
  });

  assert.equal(result.status, 201);
  assert.equal(result.body.fee, 4_800);              // percent fee
  assert.equal(result.body.total, 604_800);          // amount + fee
  assert.equal(result.body.from.id, 'alice-percent');
  assert.equal(result.body.to.id, 'bob-percent');

  // verify balances match the calculations above
  assert.equal(await app.balance('alice-percent'), 395_200);
  assert.equal(await app.balance('bob-percent'), 600_000);
});

test('fee quote includes total', async () => {
  // amount 20_000 triggers flat fee of 500
  // fee = 500
  // total = amount + fee = 20_000 + 500 = 20_500
  const result = await app.call('POST', '/fees/quote', {
    type: 'send',
    amount: 20_000,
  });

  assert.equal(result.status, 200);
  assert.equal(result.body.type, 'send');
  assert.equal(result.body.amount, 20_000);
  assert.equal(result.body.fee, 500);
  assert.equal(result.body.total, 20_500);
});


# docs/api.md
# API as it stands today

All bodies are JSON. Money is a whole number of UGX. Errors look like `{ "error": { "code": "...", "message": "..." } }`.

| Method and path                  | What it does                                                          |
| -------------------------------- | --------------------------------------------------------------------- |
| `GET /health`                    | Answers `{ "ok": true }`.                                             |
| `POST /accounts`                 | Creates a wallet from `{ id, name, openingBalance? }`. Answers 201.   |
| `GET /accounts/:id`              | Returns `{ id, name, currency, balance }`.                            |
| `GET /accounts/:id/statement`    | Returns `{ entries }`, oldest first. Each entry is `{ seq, kind, memo, at, amount }`, where `amount` is the net change for that account. |
| `POST /fees/quote`               | Takes `{ type, amount }` and returns `{ type, amount, fee }`.         |
| `POST /transfers`                | Sends `{ from, to, amount }`. The sender pays the fee on top. Answers 201 with `{ fee, from: { id, balance }, to: { id, balance } }`. |

`POST /transfers` honours an `Idempotency-Key` header: a repeat of the same request with the same key returns the first response and moves no money.

`SYSTEM_FEES` and `SYSTEM_FLOAT` are real accounts. They can be read with `GET /accounts/:id` and `GET /accounts/:id/statement` like any wallet.

## Error codes in use

| Code                 | Status | Meaning                                              |
| -------------------- | ------ | ---------------------------------------------------- |
| `INVALID_JSON`       | 400    | The body is not valid JSON.                          |
| `INVALID_BODY`       | 400    | The body is missing a field or has the wrong shape.  |
| `INVALID_AMOUNT`     | 400    | Not a positive whole number up to 5,000,000.         |
| `INVALID_TYPE`       | 400    | Unknown transaction type for a quote.                |
| `SELF_TRANSFER`      | 400    | Sender and receiver are the same account.            |
| `NOT_FOUND`          | 404    | No such route.                                       |
| `ACCOUNT_NOT_FOUND`  | 404    | No such account.                                     |
| `ACCOUNT_EXISTS`     | 409    | The account id is taken.                             |
| `INSUFFICIENT_FUNDS` | 422    | The balance cannot cover the amount plus charges.    |

## Ledger

Every movement of money is one entry in a double-entry journal. Debits equal credits in every entry. A wallet's balance is its credits minus its debits, so `SYSTEM_FLOAT` goes negative as wallets are funded, and the balances of all accounts in the store add up to zero.

The store takes a clock function, which the tests replace with a fake so that dates are predictable.


# Source files and their functions
src/accounts.js: requireAccount, account, accountView, createAccount, account
src/api/idempotency.js: seen, recall, remember
src/api/routes.js: reply, quoteFee, band, postTransfer, input, key, cached, response, routes
src/api/server.js: PARAM_PATTERN, compiled, names, source, findRoute, match, readJson, chunks, send, createApp, server, url, found, body, result
src/config.js: DEFAULT_CURRENCY, MAX_AMOUNT, ACCOUNT_ID_PATTERN, SYSTEM_ACCOUNTS
src/errors.js: invalidJson, invalidBody, invalidAmount, invalidType, selfTransfer, routeNotFound, accountNotFound, accountExists, insufficientFunds
src/fees/calculate.js: calculateFee, bands, band
src/fees/schedule.js: SCHEDULE
src/index.js: port
src/ledger/ledger.js: createLedger, entries, post, normalized, debits, credits, entry, balance, statementFor
src/ledger/transfer.js: sendMoney, fee, lines
src/store.js: createStore, accounts
src/validation.js: QUOTE_TYPES, requireObject, requireAmount, requireAccountId, validateNewAccount, validateTransfer, validateQuote
