You are fixing one ticket in a small Node.js codebase (ES modules, no dependencies).
Rules:
- You may edit only files under src/ and docs/.
- Never touch test/, acceptance/, notary-tests/, scripts/, backlog/, package.json or tests.lock.json.
- Do not add dependencies. Node standard library only.
- Do not run git.
- Keep `npm test` (the regression suite) green.

# Repository

--- AGENTS.md ---
# Notes for coding agents working in this repository

This is a small mobile money fee and ledger API in plain Node (ES modules, no dependencies).

- Run the regression suite with `npm test`. It must stay green.
- Run one task's acceptance tests with `node --test acceptance/T01.test.js` (swap the id). Run `npm run grade` for everything.
- Do not edit anything under `test/` or `acceptance/`, `backlog/backlog.json` or `scripts/`. `npm run verify:tests` fails if you do, and the fix is to restore the files, never to regenerate `tests.lock.json`.
- Do not add dependencies. Node 20 or newer, standard library only.
- Money is always a whole number of UGX. Never use floating point for stored amounts.
- Every movement of money goes through `store.ledger.post` as one balanced entry.
- `docs/api.md` describes the endpoints and error codes that exist today. Follow the same response and error shapes in new code.
- Errors are created in `src/errors.js` and thrown as `AppError`. The server turns them into JSON responses.
--- docs/api.md ---
# API as it stands today

All bodies are JSON. Money is a whole number of UGX. Errors look like `{ "error": { "code": "...", "message": "..." } }`.

| Method and path                  | What it does                                                          |
| -------------------------------- | --------------------------------------------------------------------- |
| `GET /health`                    | Answers `{ "ok": true }`.                                             |
| `POST /accounts`                 | Creates a wallet from `{ id, name, openingBalance? }`. Answers 201.   |
| `GET /accounts/:id`              | Returns `{ id, name, currency, balance }`.                            |
| `GET /accounts/:id/statement`    | Returns `{ entries }`, oldest first. Each entry is `{ seq, kind, memo, at, amount }`, where `amount` is the net change for that account. |
| `POST /fees/quote`               | Takes `{ type, amount }` and returns `{ type, amount, fee }`.         |
| `POST /transfers`                | Sends `{ from, to, amount }`. The sender pays the fee on top. Answers 201 with `{ fee, from: { id, balance }, to: { id, balance } }`. |

`POST /transfers` honours an `Idempotency-Key` header: a repeat of the same request with the same key returns the first response and moves no money.

`SYSTEM_FEES` and `SYSTEM_FLOAT` are real accounts. They can be read with `GET /accounts/:id` and `GET /accounts/:id/statement` like any wallet.

## Error codes in use

| Code                 | Status | Meaning                                              |
| -------------------- | ------ | ---------------------------------------------------- |
| `INVALID_JSON`       | 400    | The body is not valid JSON.                          |
| `INVALID_BODY`       | 400    | The body is missing a field or has the wrong shape.  |
| `INVALID_AMOUNT`     | 400    | Not a positive whole number up to 5,000,000.         |
| `INVALID_TYPE`       | 400    | Unknown transaction type for a quote.                |
| `SELF_TRANSFER`      | 400    | Sender and receiver are the same account.            |
| `NOT_FOUND`          | 404    | No such route.                                       |
| `ACCOUNT_NOT_FOUND`  | 404    | No such account.                                     |
| `ACCOUNT_EXISTS`     | 409    | The account id is taken.                             |
| `INSUFFICIENT_FUNDS` | 422    | The balance cannot cover the amount plus charges.    |

## Ledger

Every movement of money is one entry in a double-entry journal. Debits equal credits in every entry. A wallet's balance is its credits minus its debits, so `SYSTEM_FLOAT` goes negative as wallets are funded, and the balances of all accounts in the store add up to zero.

The store takes a clock function, which the tests replace with a fake so that dates are predictable.
--- docs/fees.md ---
# Fee schedule

The schedule lives in `src/fees/schedule.js`. Amounts are whole Ugandan shillings (UGX). A band applies when the amount is at or below its upper limit and above the previous band's limit.

## Send

| Amount up to | Fee            |
| ------------ | -------------- |
| 5,000        | 150 flat       |
| 50,000       | 500 flat       |
| 500,000      | 1% of amount   |
| 5,000,000    | 0.8% of amount |

The sender pays the fee on top of the amount. The fee is credited to `SYSTEM_FEES`.

The rates in this repository are made up for the exercise. They are not the rates of any real operator or tax authority.
--- docs/limits.md ---
# Daily send limits (compliance policy CP-7)

The limit is the most a single account may send in one UTC day. It is set by the account's KYC tier.

| KYC tier | Daily send limit (UGX) |
| -------- | ---------------------- |
| tier1    | 500,000                |
| tier2    | 2,000,000              |
| tier3    | 5,000,000              |

Accounts with no verification on file are treated as tier1.
--- src/accounts.js ---
import { DEFAULT_CURRENCY, SYSTEM_ACCOUNTS } from './config.js';
import { accountExists, accountNotFound } from './errors.js';

export function requireAccount(store, id) {
  const account = store.accounts.get(id);
  if (!account) throw accountNotFound(id);
  return account;
}

export function accountView(store, account) {
  return {
    id: account.id,
    name: account.name,
    currency: account.currency,
    balance: store.ledger.balance(account.id),
  };
}

export function createAccount(store, { id, name, openingBalance, kind }) {
  if (store.accounts.has(id)) throw accountExists(id);
  const account = {
    id,
    name,
    currency: DEFAULT_CURRENCY,
    // store optional kind (e.g., 'merchant') for later checks
    ...(kind ? { kind } : {}),
  };
  store.accounts.set(id, account);
  if (openingBalance > 0) {
    store.ledger.post({
      kind: 'opening',
      memo: `opening balance for ${id}`,
      lines: [
        { account: SYSTEM_ACCOUNTS.float, debit: openingBalance },
        { account: id, credit: openingBalance },
      ],
    });
  }
  return accountView(store, account);
}
--- src/api/idempotency.js ---
const seen = new Map();

export function recall(key) {
  return key === undefined ? undefined : seen.get(key);
}

export function remember(key, response) {
  if (key !== undefined) seen.set(key, response);
}
--- src/api/routes.js ---
import { accountView, createAccount, requireAccount } from '../accounts.js';
import { SCHEDULE } from '../fees/schedule.js';
import { sendMoney } from '../ledger/transfer.js';
import { payMerchant } from '../ledger/payment.js';
import { validateNewAccount, validateQuote, validateTransfer, validatePayment } from '../validation.js';
import { recall, remember } from './idempotency.js';

const reply = (status, body) => ({ status, body });

function quoteFee(type, amount) {
  const band = SCHEDULE[type].find((candidate) => amount <= candidate.upTo);
  if (band.flat !== undefined) return band.flat;
  return Math.floor((amount * band.percent) / 100);
}

function postTransfer({ store, body, headers }) {
  const input = validateTransfer(body);
  const key = headers['Idempotency-Key'];
  const cached = recall(key);
  if (cached) return cached;
  const response = reply(201, sendMoney(store, input));
  remember(key, response);
  return response;
}

function postPayment({ store, body }) {
  const input = validatePayment(body);
  const result = payMerchant(store, input);
  return reply(201, result);
}

export const routes = [
  {
    method: 'GET',
    path: '/health',
    handler: () => reply(200, { ok: true }),
  },
  {
    method: 'POST',
    path: '/accounts',
    handler: ({ store, body }) => reply(201, createAccount(store, validateNewAccount(body))),
  },
  {
    method: 'GET',
    path: '/accounts/:id',
    handler: ({ store, params }) => reply(200, accountView(store, requireAccount(store, params.id))),
  },
  {
    method: 'GET',
    path: '/accounts/:id/statement',
    handler: ({ store, params }) => {
      requireAccount(store, params.id);
      return reply(200, { entries: store.ledger.statementFor(params.id) });
    },
  },
  {
    method: 'POST',
    path: '/fees/quote',
    handler: ({ body }) => {
      const { type, amount } = validateQuote(body);
      return reply(200, { type, amount, fee: quoteFee(type, amount) });
    },
  },
  {
    method: 'POST',
    path: '/transfers',
    handler: postTransfer,
  },
  {
    method: 'POST',
    path: '/payments',
    handler: postPayment,
  },
];
--- src/api/server.js ---
import http from 'node:http';
import { AppError, invalidJson, routeNotFound } from '../errors.js';
import { createStore } from '../store.js';
import { routes } from './routes.js';

const PARAM_PATTERN = /:([a-z]+)/g;

const compiled = routes.map((route) => {
  const names = [];
  const source = route.path.replace(PARAM_PATTERN, (_, name) => {
    names.push(name);
    return '([^/]+)';
  });
  return { route, names, regex: new RegExp(`^${source}$`) };
});

function findRoute(method, pathname) {
  for (const { route, names, regex } of compiled) {
    const match = route.method === method && regex.exec(pathname);
    if (match) {
      return { route, params: Object.fromEntries(names.map((name, index) => [name, match[index + 1]])) };
    }
  }
  return null;
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (chunks.length === 0) return undefined;
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw invalidJson();
  }
}

function send(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(body));
}

export function createApp(store = createStore()) {
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const found = findRoute(req.method, url.pathname);
      if (!found) throw routeNotFound();
      const body = await readJson(req);
      const result = await found.route.handler({
        store,
        params: found.params,
        query: url.searchParams,
        body,
        headers: req.headers,
      });
      send(res, result.status, result.body);
    } catch (error) {
      if (error instanceof AppError) {
        send(res, error.status, { error: { code: error.code, message: error.message } });
        return;
      }
      console.error(error);
      send(res, 500, { error: { code: 'INTERNAL', message: 'internal error' } });
    }
  });
  return { server, store };
}
--- src/config.js ---
export const DEFAULT_CURRENCY = 'UGX';
export const MAX_AMOUNT = 5_000_000;
export const ACCOUNT_ID_PATTERN = /^[A-Za-z0-9_-]{3,32}$/;

export const SYSTEM_ACCOUNTS = {
  fees: 'SYSTEM_FEES',
  float: 'SYSTEM_FLOAT',
};
--- src/errors.js ---
export class AppError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export const invalidJson = () => new AppError(400, 'INVALID_JSON', 'request body is not valid JSON');
export const invalidBody = (message) => new AppError(400, 'INVALID_BODY', message);
export const invalidAmount = () =>
  new AppError(400, 'INVALID_AMOUNT', 'amount must be a positive whole number within the allowed maximum');
export const invalidType = () => new AppError(400, 'INVALID_TYPE', 'unknown transaction type');
export const selfTransfer = () => new AppError(400, 'SELF_TRANSFER', 'sender and receiver must differ');
export const routeNotFound = () => new AppError(404, 'NOT_FOUND', 'no such route');
export const accountNotFound = (id) => new AppError(404, 'ACCOUNT_NOT_FOUND', `account ${id} not found`);
export const accountExists = (id) => new AppError(409, 'ACCOUNT_EXISTS', `account ${id} already exists`);
export const insufficientFunds = () =>
  new AppError(422, 'INSUFFICIENT_FUNDS', 'balance is too low for the amount plus charges');
export const notAMerchant = () => new AppError(422, 'NOT_A_MERCHANT', 'account is not a merchant');
--- src/fees/calculate.js ---
import { SCHEDULE } from './schedule.js';

export function calculateFee(type, amount) {
  const bands = SCHEDULE[type];
  if (!bands) throw new Error(`no fee schedule for ${type}`);
  const band = bands.find((candidate) => amount <= candidate.upTo);
  if (!band) throw new Error(`amount ${amount} is above the top fee band for ${type}`);
  if (band.flat !== undefined) return band.flat;
  if (band.min !== undefined) {
    return Math.max(Math.round((amount * band.percent) / 100), band.min);
  }
  return Math.floor((amount * band.percent) / 100);
}
--- src/fees/schedule.js ---
export const SCHEDULE = {
  send: [
    { upTo: 5_000, percent: 5, min: 100 },
    { upTo: 50_000, flat: 500 },
    { upTo: 500_000, percent: 1 },
    { upTo: 5_000_000, percent: 0.8 },
  ],
};
--- src/index.js ---
import { createApp } from './api/server.js';

const port = Number(process.env.PORT ?? 3000);
const { server } = createApp();
server.listen(port, () => {
  console.log(`ledger api listening on http://localhost:${port}`);
});
--- src/ledger/ledger.js ---
// Balances are credits minus debits, so SYSTEM_FLOAT goes negative as wallets are funded
// and every account in the store always sums to zero.
export function createLedger(clock) {
  const entries = [];

  function post({ kind, memo, lines }) {
    const normalized = lines.map(({ account, debit = 0, credit = 0 }) => ({ account, debit, credit }));
    const debits = normalized.reduce((sum, line) => sum + line.debit, 0);
    const credits = normalized.reduce((sum, line) => sum + line.credit, 0);
    if (debits !== credits) {
      throw new Error(`unbalanced ledger entry: debits ${debits}, credits ${credits}`);
    }
    const entry = { seq: entries.length + 1, kind, memo, at: clock().toISOString(), lines: normalized };
    entries.push(entry);
    return entry;
  }

  function balance(accountId) {
    return entries
      .flatMap((entry) => entry.lines)
      .filter((line) => line.account === accountId)
      .reduce((sum, line) => sum + line.credit - line.debit, 0);
  }

  function statementFor(accountId) {
    return entries
      .filter((entry) => entry.lines.some((line) => line.account === accountId))
      .map((entry) => ({
        seq: entry.seq,
        kind: entry.kind,
        memo: entry.memo,
        at: entry.at,
        amount: entry.lines
          .filter((line) => line.account === accountId)
          .reduce((sum, line) => sum + line.credit - line.debit, 0),
      }));
  }

  return { post, balance, statementFor };
}
--- src/ledger/payment.js ---
import { requireAccount } from '../accounts.js';
import { SYSTEM_ACCOUNTS } from '../config.js';
import { insufficientFunds, selfTransfer, notAMerchant } from '../errors.js';

/**
 * Process a merchant payment.
 *
 * Customer (from) is debited the full amount.
 * Merchant is credited amount‑fee, where fee = round(1% of amount) (half‑up).
 * Fee is credited to SYSTEM_FEES.
 *
 * Throws:
 *   - selfTransfer()   if from === merchant
 *   - accountNotFound   via requireAccount if either party missing
 *   - notAMerchant()    if merchant account is not marked as a merchant
 *   - insufficientFunds() if from's balance < amount
 */
export function payMerchant(store, { from, merchant, amount }) {
  if (from === merchant) throw selfTransfer();

  // ensure both accounts exist
  const fromAcc = requireAccount(store, from);
  const merchantAcc = requireAccount(store, merchant);

  // merchant must be flagged as a merchant (kind === 'merchant')
  if (merchantAcc.kind !== 'merchant') throw notAMerchant();

  const { ledger } = store;

  // fee calculation: 1% rounded half‑up
  const fee = Math.round(amount * 0.01);

  // check sufficient funds (customer pays exact amount, no fee on them)
  if (ledger.balance(from) < amount) throw insufficientFunds();

  const lines = [
    { account: from, debit: amount },
    { account: merchant, credit: amount - fee },
  ];
  if (fee > 0) {
    lines.push({ account: SYSTEM_ACCOUNTS.fees, credit: fee });
  }

  ledger.post({ kind: 'payment', memo: `payment from ${from} to ${merchant}`, lines });

  return {
    fee,
    from: { id: from, balance: ledger.balance(from) },
    merchant: { id: merchant, balance: ledger.balance(merchant) },
  };
}
--- src/ledger/transfer.js ---
import { requireAccount } from '../accounts.js';
import { SYSTEM_ACCOUNTS } from '../config.js';
import { insufficientFunds, selfTransfer } from '../errors.js';
import { calculateFee } from '../fees/calculate.js';

export function sendMoney(store, { from, to, amount }) {
  if (from === to) throw selfTransfer();
  requireAccount(store, from);
  requireAccount(store, to);
  const { ledger } = store;
  const fee = calculateFee('send', amount);
  if (ledger.balance(from) < amount + fee) throw insufficientFunds();

  const lines = [
    { account: from, debit: amount + fee },
    { account: to, credit: amount },
  ];
  if (fee > 0) lines.push({ account: SYSTEM_ACCOUNTS.fees, credit: fee });
  ledger.post({ kind: 'send', memo: `send ${from} to ${to}`, lines });

  return {
    fee,
    from: { id: from, balance: ledger.balance(from) },
    to: { id: to, balance: ledger.balance(to) },
  };
}
--- src/store.js ---
import { DEFAULT_CURRENCY, SYSTEM_ACCOUNTS } from './config.js';
import { createLedger } from './ledger/ledger.js';

export function createStore({ clock = () => new Date() } = {}) {
  const accounts = new Map();
  for (const id of Object.values(SYSTEM_ACCOUNTS)) {
    accounts.set(id, { id, name: id, currency: DEFAULT_CURRENCY, system: true });
  }
  return { accounts, ledger: createLedger(clock), clock };
}
--- src/validation.js ---
import { ACCOUNT_ID_PATTERN, MAX_AMOUNT } from './config.js';
import { invalidAmount, invalidBody, invalidType } from './errors.js';

const QUOTE_TYPES = ['send'];

export function requireObject(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    throw invalidBody('body must be a JSON object');
  }
  return body;
}

export function requireAmount(value) {
  if (!Number.isInteger(value) || value <= 0 || value > MAX_AMOUNT) throw invalidAmount();
  return value;
}

export function requireAccountId(value, field) {
  if (typeof value !== 'string' || !ACCOUNT_ID_PATTERN.test(value)) {
    throw invalidBody(`${field} must be a valid account id`);
  }
  return value;
}

export function validateNewAccount(body) {
  const { id, name, openingBalance = 0, kind } = requireObject(body);
  requireAccountId(id, 'id');
  if (typeof name !== 'string' || name.trim() === '') throw invalidBody('name is required');
  if (!Number.isInteger(openingBalance) || openingBalance < 0) {
    throw invalidBody('openingBalance must be a non-negative whole number');
  }
  // kind is optional; keep as‑is for creator to use (e.g., 'merchant')
  return { id, name: name.trim(), openingBalance, kind };
}

export function validateTransfer(body) {
  const { from, to, amount } = requireObject(body);
  return {
    from: requireAccountId(from, 'from'),
    to: requireAccountId(to, 'to'),
    amount: requireAmount(amount),
  };
}

export function validateQuote(body) {
  const { type, amount } = requireObject(body);
  if (!QUOTE_TYPES.includes(type)) throw invalidType();
  return { type, amount: requireAmount(amount) };
}

export function validatePayment(body) {
  const { from, merchant, amount } = requireObject(body);
  return {
    from: requireAccountId(from, 'from'),
    merchant: requireAccountId(merchant, 'merchant'),
    amount: requireAmount(amount),
  };
}

# Ticket H05: Merchants keep the full payment

Merchants are complaining that payments take a fee out of what they are owed. For POST /payments the merchant must be credited exactly the amount the customer entered. The fee (1% of the amount, rounded half up to the nearest whole shilling) is charged to the customer on top: the customer is debited the amount plus the fee. The fee still goes to SYSTEM_FEES and still appears as fee in the response.

A customer who cannot cover the amount plus the fee gets 422 INSUFFICIENT_FUNDS and nothing changes.

# Acceptance test

This locked test must pass: notary-tests/H05.test.js

```js
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp } from '../test/helpers.js';

let app;
before(async () => {
  // start the app with the default fake clock
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('payment credits the merchant the full amount and charges the customer the fee on top', async () => {
  // setup accounts
  await app.open('customer1', 20_100); // enough for amount + fee
  await app.open('merchant1', 0);

  // record SYSTEM_FEES balance before
  const feesBefore = await app.balance('SYSTEM_FEES');

  const amount = 10_000;
  // fee = 1% of amount, rounded half-up
  // 1% of 10_000 = 100 → already whole
  // expectedFee = 100
  const expectedFee = 100;
  // total debited from customer = amount + fee = 10_100
  const totalDebited = amount + expectedFee;
  // expected customer balance = opening 20_100 - totalDebited = 10_000
  const expectedCustomerBalance = 20_100 - totalDebited;
  // expected merchant balance = amount (full payment) = 10_000
  const expectedMerchantBalance = amount;

  const result = await app.call('POST', '/payments', {
    from: 'customer1',
    merchant: 'merchant1',
    amount,
  });

  // success
  assert.equal(result.status, 201);
  assert.equal(result.body.fee, expectedFee);
  assert.equal(result.body.from.id, 'customer1');
  assert.equal(result.body.from.balance, expectedCustomerBalance);
  assert.equal(result.body.merchant.id, 'merchant1');
  assert.equal(result.body.merchant.balance, expectedMerchantBalance);

  // verify via API
  assert.equal(await app.balance('customer1'), expectedCustomerBalance);
  assert.equal(await app.balance('merchant1'), expectedMerchantBalance);

  // fee account increased by the fee
  const feesAfter = await app.balance('SYSTEM_FEES');
  assert.equal(feesAfter - feesBefore, expectedFee);
});

test('payment fails with INSUFFICIENT_FUNDS when the customer cannot cover amount plus fee', async () => {
  await app.open('customer2', 5_000); // not enough for amount+fee
  await app.open('merchant2', 0);

  const amount = 5_000;
  // fee = 1% of amount, rounded half-up
  // 1% of 5_000 = 50 → whole
  const expectedFee = 50;
  const totalNeeded = amount + expectedFee; // 5_050

  // record balances before
  const custBefore = await app.balance('customer2');
  const merchBefore = await app.balance('merchant2');
  const feesBefore = await app.balance('SYSTEM_FEES');

  const result = await app.call('POST', '/payments', {
    from: 'customer2',
    merchant: 'merchant2',
    amount,
  });

  // ticket specifies 422
  assert.equal(result.status, 422);
  // ensure nothing changed
  assert.equal(await app.balance('customer2'), custBefore);
  assert.equal(await app.balance('merchant2'), merchBefore);
  assert.equal(await app.balance('SYSTEM_FEES'), feesBefore);
});

test('payment fee is rounded half-up for amounts that produce fractional fees', async () => {
  await app.open('customer3', 2_000); // enough to cover total
  await app.open('merchant3', 0);

  const amount = 1_050;
  // 1% of 1_050 = 10.5 → round half-up => 11
  const rawFee = amount * 0.01; // 10.5
  const expectedFee = Math.round(rawFee); // 11
  // total debited = amount + fee = 1_061
  const totalDebited = amount + expectedFee;
  // expected customer balance = opening 2_000 - totalDebited = 939
  const expectedCustomerBalance = 2_000 - totalDebited;
  // merchant receives full amount
  const expectedMerchantBalance = amount;

  const result = await app.call('POST', '/payments', {
    from: 'customer3',
    merchant: 'merchant3',
    amount,
  });

  assert.equal(result.status, 201);
  assert.equal(result.body.fee, expectedFee);
  assert.equal(result.body.from.balance, expectedCustomerBalance);
  assert.equal(result.body.merchant.balance, expectedMerchantBalance);
  assert.equal(await app.balance('customer3'), expectedCustomerBalance);
  assert.equal(await app.balance('merchant3'), expectedMerchantBalance);
});
```

# Output

Return ONLY changed files, each complete, in this exact format:
=== FILE: src/path/file.js ===
<entire new file content>
=== END FILE ===
Then one line: === SUMMARY: <what you changed> ===
