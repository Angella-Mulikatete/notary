Write the acceptance test for the ticket below, as one Node.js test file.
Rules:
- Use node:test and node:assert/strict, and the helpers in test/helpers.js (import from '../test/helpers.js'). Import NOTHING else: no files under src/. Test through the HTTP API only.
- Follow the style of the example tests: before/after hooks that start and close the app, one behaviour per test.
- Assert only what the ticket states explicitly. Compute expected numbers from the ticket and the docs. Do not assert error message text, field names or status codes the ticket does not give; for a rejection the ticket does not specify, assert result.status >= 400.
- Other tickets in the backlog may change shared rules (fees, duties, limits, ids). Do not depend on a value another ticket changes unless this ticket states it; pick amounts and inputs that other tickets leave alone, and assert what this ticket owns rather than totals other tickets also move.
- Use fresh, unique account ids in every test so tests do not share state. Ids are plain ASCII: lowercase letters, digits and '-' only.
- Setup must succeed once the ticket is done: open accounts with far more money than the test moves, keep amounts small and well under every limit any ticket mentions, and check setup responses before asserting.
- Above every expected number, write the arithmetic in a comment, step by step from the ticket and docs.
- Write 3 to 6 tests. At least one must fail on the current code, because the ticket is not implemented yet.
- Reply with the complete file in one ```js block and nothing else.

# Repository

--- AGENTS.md ---
# Notes for coding agents working in this repository

This is a small mobile money fee and ledger API in plain Node (ES modules, no dependencies).

- Run the regression suite with `npm test`. It must stay green.
- Run one task's acceptance tests with `node --test acceptance/T01.test.js` (swap the id). Run `npm run grade` for everything.
- Do not edit anything under `test/` or `acceptance/`, `backlog/backlog.json` or `scripts/`. `npm run verify:tests` fails if you do, and the fix is to restore the files, never to regenerate `tests.lock.json`.
- Do not add dependencies. Node 20 or newer, standard library only.
- Money is always a whole number of UGX. Never use floating point for stored amounts.
- Every movement of money goes through `store.ledger.post` as one balanced entry.
- `docs/api.md` describes the endpoints and error codes that exist today. Follow the same response and error shapes in new code.
- Errors are created in `src/errors.js` and thrown as `AppError`. The server turns them into JSON responses.
--- docs/api.md ---
# API as it stands today

All bodies are JSON. Money is a whole number of UGX. Errors look like `{ "error": { "code": "...", "message": "..." } }`.

| Method and path                  | What it does                                                          |
| -------------------------------- | --------------------------------------------------------------------- |
| `GET /health`                    | Answers `{ "ok": true }`.                                             |
| `POST /accounts`                 | Creates a wallet from `{ id, name, openingBalance? }`. Answers 201.   |
| `GET /accounts/:id`              | Returns `{ id, name, currency, balance }`.                            |
| `GET /accounts/:id/statement`    | Returns `{ entries }`, oldest first. Each entry is `{ seq, kind, memo, at, amount }`, where `amount` is the net change for that account. |
| `POST /fees/quote`               | Takes `{ type, amount }` and returns `{ type, amount, fee }`.         |
| `POST /transfers`                | Sends `{ from, to, amount }`. The sender pays the fee on top. Answers 201 with `{ fee, from: { id, balance }, to: { id, balance } }`. |

`POST /transfers` honours an `Idempotency-Key` header: a repeat of the same request with the same key returns the first response and moves no money.

`SYSTEM_FEES` and `SYSTEM_FLOAT` are real accounts. They can be read with `GET /accounts/:id` and `GET /accounts/:id/statement` like any wallet.

## Error codes in use

| Code                 | Status | Meaning                                              |
| -------------------- | ------ | ---------------------------------------------------- |
| `INVALID_JSON`       | 400    | The body is not valid JSON.                          |
| `INVALID_BODY`       | 400    | The body is missing a field or has the wrong shape.  |
| `INVALID_AMOUNT`     | 400    | Not a positive whole number up to 5,000,000.         |
| `INVALID_TYPE`       | 400    | Unknown transaction type for a quote.                |
| `SELF_TRANSFER`      | 400    | Sender and receiver are the same account.            |
| `NOT_FOUND`          | 404    | No such route.                                       |
| `ACCOUNT_NOT_FOUND`  | 404    | No such account.                                     |
| `ACCOUNT_EXISTS`     | 409    | The account id is taken.                             |
| `INSUFFICIENT_FUNDS` | 422    | The balance cannot cover the amount plus charges.    |

## Ledger

Every movement of money is one entry in a double-entry journal. Debits equal credits in every entry. A wallet's balance is its credits minus its debits, so `SYSTEM_FLOAT` goes negative as wallets are funded, and the balances of all accounts in the store add up to zero.

The store takes a clock function, which the tests replace with a fake so that dates are predictable.
--- docs/fees.md ---
# Fee schedule

The schedule lives in `src/fees/schedule.js`. Amounts are whole Ugandan shillings (UGX). A band applies when the amount is at or below its upper limit and above the previous band's limit.

## Send

| Amount up to | Fee            |
| ------------ | -------------- |
| 5,000        | 150 flat       |
| 50,000       | 500 flat       |
| 500,000      | 1% of amount   |
| 5,000,000    | 0.8% of amount |

The sender pays the fee on top of the amount. The fee is credited to `SYSTEM_FEES`.

The rates in this repository are made up for the exercise. They are not the rates of any real operator or tax authority.
--- docs/limits.md ---
# Daily send limits (compliance policy CP-7)

The limit is the most a single account may send in one UTC day. It is set by the account's KYC tier.

| KYC tier | Daily send limit (UGX) |
| -------- | ---------------------- |
| tier1    | 500,000                |
| tier2    | 2,000,000              |
| tier3    | 5,000,000              |

Accounts with no verification on file are treated as tier1.
--- src/accounts.js ---
import { DEFAULT_CURRENCY, SYSTEM_ACCOUNTS } from './config.js';
import { accountExists, accountNotFound } from './errors.js';

export function requireAccount(store, id) {
  const account = store.accounts.get(id);
  if (!account) throw accountNotFound(id);
  return account;
}

export function accountView(store, account) {
  return {
    id: account.id,
    name: account.name,
    currency: account.currency,
    balance: store.ledger.balance(account.id),
  };
}

export function createAccount(store, { id, name, openingBalance }) {
  if (store.accounts.has(id)) throw accountExists(id);
  const account = { id, name, currency: DEFAULT_CURRENCY };
  store.accounts.set(id, account);
  if (openingBalance > 0) {
    store.ledger.post({
      kind: 'opening',
      memo: `opening balance for ${id}`,
      lines: [
        { account: SYSTEM_ACCOUNTS.float, debit: openingBalance },
        { account: id, credit: openingBalance },
      ],
    });
  }
  return accountView(store, account);
}
--- src/api/idempotency.js ---
const seen = new Map();

export function recall(key) {
  return key === undefined ? undefined : seen.get(key);
}

export function remember(key, response) {
  if (key !== undefined) seen.set(key, response);
}
--- src/api/routes.js ---
import { accountView, createAccount, requireAccount } from '../accounts.js';
import { SCHEDULE } from '../fees/schedule.js';
import { sendMoney } from '../ledger/transfer.js';
import { validateNewAccount, validateQuote, validateTransfer } from '../validation.js';
import { recall, remember } from './idempotency.js';

const reply = (status, body) => ({ status, body });

function quoteFee(type, amount) {
  const band = SCHEDULE[type].find((candidate) => amount <= candidate.upTo);
  if (band.flat !== undefined) return band.flat;
  return Math.floor((amount * band.percent) / 100);
}

function postTransfer({ store, body, headers }) {
  const input = validateTransfer(body);
  const key = headers['Idempotency-Key'];
  const cached = recall(key);
  if (cached) return cached;
  const response = reply(201, sendMoney(store, input));
  remember(key, response);
  return response;
}

export const routes = [
  {
    method: 'GET',
    path: '/health',
    handler: () => reply(200, { ok: true }),
  },
  {
    method: 'POST',
    path: '/accounts',
    handler: ({ store, body }) => reply(201, createAccount(store, validateNewAccount(body))),
  },
  {
    method: 'GET',
    path: '/accounts/:id',
    handler: ({ store, params }) => reply(200, accountView(store, requireAccount(store, params.id))),
  },
  {
    method: 'GET',
    path: '/accounts/:id/statement',
    handler: ({ store, params }) => {
      requireAccount(store, params.id);
      return reply(200, { entries: store.ledger.statementFor(params.id) });
    },
  },
  {
    method: 'POST',
    path: '/fees/quote',
    handler: ({ body }) => {
      const { type, amount } = validateQuote(body);
      return reply(200, { type, amount, fee: quoteFee(type, amount) });
    },
  },
  {
    method: 'POST',
    path: '/transfers',
    handler: postTransfer,
  },
];
--- src/api/server.js ---
import http from 'node:http';
import { AppError, invalidJson, routeNotFound } from '../errors.js';
import { createStore } from '../store.js';
import { routes } from './routes.js';

const PARAM_PATTERN = /:([a-z]+)/g;

const compiled = routes.map((route) => {
  const names = [];
  const source = route.path.replace(PARAM_PATTERN, (_, name) => {
    names.push(name);
    return '([^/]+)';
  });
  return { route, names, regex: new RegExp(`^${source}$`) };
});

function findRoute(method, pathname) {
  for (const { route, names, regex } of compiled) {
    const match = route.method === method && regex.exec(pathname);
    if (match) {
      return { route, params: Object.fromEntries(names.map((name, index) => [name, match[index + 1]])) };
    }
  }
  return null;
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (chunks.length === 0) return undefined;
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw invalidJson();
  }
}

function send(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(body));
}

export function createApp(store = createStore()) {
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const found = findRoute(req.method, url.pathname);
      if (!found) throw routeNotFound();
      const body = await readJson(req);
      const result = await found.route.handler({
        store,
        params: found.params,
        query: url.searchParams,
        body,
        headers: req.headers,
      });
      send(res, result.status, result.body);
    } catch (error) {
      if (error instanceof AppError) {
        send(res, error.status, { error: { code: error.code, message: error.message } });
        return;
      }
      console.error(error);
      send(res, 500, { error: { code: 'INTERNAL', message: 'internal error' } });
    }
  });
  return { server, store };
}
--- src/config.js ---
export const DEFAULT_CURRENCY = 'UGX';
export const MAX_AMOUNT = 5_000_000;
export const ACCOUNT_ID_PATTERN = /^[A-Za-z0-9_-]{3,32}$/;

export const SYSTEM_ACCOUNTS = {
  fees: 'SYSTEM_FEES',
  float: 'SYSTEM_FLOAT',
};
--- src/errors.js ---
export class AppError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export const invalidJson = () => new AppError(400, 'INVALID_JSON', 'request body is not valid JSON');
export const invalidBody = (message) => new AppError(400, 'INVALID_BODY', message);
export const invalidAmount = () =>
  new AppError(400, 'INVALID_AMOUNT', 'amount must be a positive whole number within the allowed maximum');
export const invalidType = () => new AppError(400, 'INVALID_TYPE', 'unknown transaction type');
export const selfTransfer = () => new AppError(400, 'SELF_TRANSFER', 'sender and receiver must differ');
export const routeNotFound = () => new AppError(404, 'NOT_FOUND', 'no such route');
export const accountNotFound = (id) => new AppError(404, 'ACCOUNT_NOT_FOUND', `account ${id} not found`);
export const accountExists = (id) => new AppError(409, 'ACCOUNT_EXISTS', `account ${id} already exists`);
export const insufficientFunds = () =>
  new AppError(422, 'INSUFFICIENT_FUNDS', 'balance is too low for the amount plus charges');
--- src/fees/calculate.js ---
import { SCHEDULE } from './schedule.js';

export function calculateFee(type, amount) {
  const bands = SCHEDULE[type];
  if (!bands) throw new Error(`no fee schedule for ${type}`);
  const band = bands.find((candidate) => amount <= candidate.upTo);
  if (!band) throw new Error(`amount ${amount} is above the top fee band for ${type}`);
  if (band.flat !== undefined) return band.flat;
  return Math.floor((amount * band.percent) / 100);
}
--- src/fees/schedule.js ---
export const SCHEDULE = {
  send: [
    { upTo: 5_000, flat: 150 },
    { upTo: 50_000, flat: 500 },
    { upTo: 500_000, percent: 1 },
    { upTo: 5_000_000, percent: 0.8 },
  ],
};
--- src/index.js ---
import { createApp } from './api/server.js';

const port = Number(process.env.PORT ?? 3000);
const { server } = createApp();
server.listen(port, () => {
  console.log(`ledger api listening on http://localhost:${port}`);
});
--- src/ledger/ledger.js ---
// Balances are credits minus debits, so SYSTEM_FLOAT goes negative as wallets are funded
// and every account in the store always sums to zero.
export function createLedger(clock) {
  const entries = [];

  function post({ kind, memo, lines }) {
    const normalized = lines.map(({ account, debit = 0, credit = 0 }) => ({ account, debit, credit }));
    const debits = normalized.reduce((sum, line) => sum + line.debit, 0);
    const credits = normalized.reduce((sum, line) => sum + line.credit, 0);
    if (debits !== credits) {
      throw new Error(`unbalanced ledger entry: debits ${debits}, credits ${credits}`);
    }
    const entry = { seq: entries.length + 1, kind, memo, at: clock().toISOString(), lines: normalized };
    entries.push(entry);
    return entry;
  }

  function balance(accountId) {
    return entries
      .flatMap((entry) => entry.lines)
      .filter((line) => line.account === accountId)
      .reduce((sum, line) => sum + line.credit - line.debit, 0);
  }

  function statementFor(accountId) {
    return entries
      .filter((entry) => entry.lines.some((line) => line.account === accountId))
      .map((entry) => ({
        seq: entry.seq,
        kind: entry.kind,
        memo: entry.memo,
        at: entry.at,
        amount: entry.lines
          .filter((line) => line.account === accountId)
          .reduce((sum, line) => sum + line.credit - line.debit, 0),
      }));
  }

  return { post, balance, statementFor };
}
--- src/ledger/transfer.js ---
import { requireAccount } from '../accounts.js';
import { SYSTEM_ACCOUNTS } from '../config.js';
import { insufficientFunds, selfTransfer } from '../errors.js';
import { calculateFee } from '../fees/calculate.js';

export function sendMoney(store, { from, to, amount }) {
  if (from === to) throw selfTransfer();
  requireAccount(store, from);
  requireAccount(store, to);
  const { ledger } = store;
  const fee = calculateFee('send', amount);
  if (ledger.balance(from) < amount + fee) throw insufficientFunds();

  const lines = [
    { account: from, debit: amount + fee },
    { account: to, credit: amount },
  ];
  if (fee > 0) lines.push({ account: SYSTEM_ACCOUNTS.fees, credit: fee });
  ledger.post({ kind: 'send', memo: `send ${from} to ${to}`, lines });

  return {
    fee,
    from: { id: from, balance: ledger.balance(from) },
    to: { id: to, balance: ledger.balance(to) },
  };
}
--- src/store.js ---
import { DEFAULT_CURRENCY, SYSTEM_ACCOUNTS } from './config.js';
import { createLedger } from './ledger/ledger.js';

export function createStore({ clock = () => new Date() } = {}) {
  const accounts = new Map();
  for (const id of Object.values(SYSTEM_ACCOUNTS)) {
    accounts.set(id, { id, name: id, currency: DEFAULT_CURRENCY, system: true });
  }
  return { accounts, ledger: createLedger(clock), clock };
}
--- src/validation.js ---
import { ACCOUNT_ID_PATTERN, MAX_AMOUNT } from './config.js';
import { invalidAmount, invalidBody, invalidType } from './errors.js';

const QUOTE_TYPES = ['send'];

export function requireObject(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    throw invalidBody('body must be a JSON object');
  }
  return body;
}

export function requireAmount(value) {
  if (!Number.isInteger(value) || value <= 0 || value > MAX_AMOUNT) throw invalidAmount();
  return value;
}

export function requireAccountId(value, field) {
  if (typeof value !== 'string' || !ACCOUNT_ID_PATTERN.test(value)) {
    throw invalidBody(`${field} must be a valid account id`);
  }
  return value;
}

export function validateNewAccount(body) {
  const { id, name, openingBalance = 0 } = requireObject(body);
  requireAccountId(id, 'id');
  if (typeof name !== 'string' || name.trim() === '') throw invalidBody('name is required');
  if (!Number.isInteger(openingBalance) || openingBalance < 0) {
    throw invalidBody('openingBalance must be a non-negative whole number');
  }
  return { id, name: name.trim(), openingBalance };
}

export function validateTransfer(body) {
  const { from, to, amount } = requireObject(body);
  return {
    from: requireAccountId(from, 'from'),
    to: requireAccountId(to, 'to'),
    amount: requireAmount(amount),
  };
}

export function validateQuote(body) {
  const { type, amount } = requireObject(body);
  if (!QUOTE_TYPES.includes(type)) throw invalidType();
  return { type, amount: requireAmount(amount) };
}

--- test/helpers.js ---
import { createApp } from '../src/api/server.js';
import { createStore } from '../src/store.js';

const MS_PER_MINUTE = 60_000;
const MS_PER_DAY = 86_400_000;

export function fakeClock(startIso = '2026-01-15T10:00:00.000Z') {
  let current = new Date(startIso);
  const clock = () => new Date(current);
  clock.advanceMinutes = (minutes) => {
    current = new Date(current.getTime() + minutes * MS_PER_MINUTE);
  };
  clock.advanceDays = (days) => {
    current = new Date(current.getTime() + days * MS_PER_DAY);
  };
  return clock;
}

export async function startApp({ clock } = {}) {
  const store = createStore(clock ? { clock } : undefined);
  const { server } = createApp(store);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;

  async function call(method, path, body, headers = {}) {
    const response = await fetch(`${base}${path}`, {
      method,
      headers: { 'content-type': 'application/json', ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await response.text();
    return { status: response.status, body: text === '' ? null : JSON.parse(text) };
  }

  async function callRaw(method, path, rawBody) {
    const response = await fetch(`${base}${path}`, {
      method,
      headers: { 'content-type': 'application/json' },
      body: rawBody,
    });
    return { status: response.status, body: await response.json() };
  }

  async function open(id, openingBalance = 0, extra = {}) {
    const result = await call('POST', '/accounts', { id, name: id, openingBalance, ...extra });
    if (result.status !== 201) {
      throw new Error(`could not open ${id}: ${result.status} ${JSON.stringify(result.body)}`);
    }
    return result.body;
  }

  async function balance(id) {
    const result = await call('GET', `/accounts/${id}`);
    return result.body.balance;
  }

  async function totalOfAllBalances() {
    let total = 0;
    for (const id of store.accounts.keys()) total += await balance(id);
    return total;
  }

  function close() {
    return new Promise((resolve) => {
      server.close(resolve);
      server.closeAllConnections();
    });
  }

  return { call, callRaw, open, balance, totalOfAllBalances, close, store };
}

# Example test: test/transfers.test.js
```js
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { startApp } from './helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('a transfer moves the amount and charges the sender the fee', async () => {
  await app.open('alice', 100_000);
  await app.open('bob', 0);
  const result = await app.call('POST', '/transfers', { from: 'alice', to: 'bob', amount: 20_000 });
  assert.equal(result.status, 201);
  assert.equal(result.body.fee, 500);
  assert.equal(result.body.from.id, 'alice');
  assert.equal(result.body.from.balance, 79_500);
  assert.equal(result.body.to.balance, 20_000);
  assert.equal(await app.balance('alice'), 79_500);
  assert.equal(await app.balance('bob'), 20_000);
});

test('the fee lands in the fees account', async () => {
  const feesBefore = await app.balance('SYSTEM_FEES');
  await app.open('carol', 200_000);
  await app.open('dave', 0);
  await app.call('POST', '/transfers', { from: 'carol', to: 'dave', amount: 100_000 });
  const feesAfter = await app.balance('SYSTEM_FEES');
  assert.equal(feesAfter - feesBefore, 1_000);
});

test('every balance in the store sums to zero', async () => {
  await app.open('erin', 500_000);
  await app.open('frank', 10_000);
  await app.call('POST', '/transfers', { from: 'erin', to: 'frank', amount: 200_000 });
  await app.call('POST', '/transfers', { from: 'frank', to: 'erin', amount: 20_000 });
  assert.equal(await app.totalOfAllBalances(), 0);
});

test('insufficient funds changes nothing', async () => {
  await app.open('gina', 10_000);
  await app.open('hugo', 0);
  const result = await app.call('POST', '/transfers', { from: 'gina', to: 'hugo', amount: 10_000 });
  assert.equal(result.status, 422);
  assert.equal(result.body.error.code, 'INSUFFICIENT_FUNDS');
  assert.equal(await app.balance('gina'), 10_000);
  assert.equal(await app.balance('hugo'), 0);
});

test('the amount plus fee may use the whole balance', async () => {
  await app.open('ivan', 20_500);
  await app.open('jade', 0);
  const result = await app.call('POST', '/transfers', { from: 'ivan', to: 'jade', amount: 20_000 });
  assert.equal(result.status, 201);
  assert.equal(await app.balance('ivan'), 0);
});

test('a wallet cannot send to itself', async () => {
  await app.open('kofi', 100_000);
  const result = await app.call('POST', '/transfers', { from: 'kofi', to: 'kofi', amount: 20_000 });
  assert.equal(result.status, 400);
  assert.equal(result.body.error.code, 'SELF_TRANSFER');
});

test('unknown accounts are a 404', async () => {
  await app.open('lena', 100_000);
  const unknownTo = await app.call('POST', '/transfers', { from: 'lena', to: 'nobody-here', amount: 20_000 });
  assert.equal(unknownTo.status, 404);
  assert.equal(unknownTo.body.error.code, 'ACCOUNT_NOT_FOUND');
  const unknownFrom = await app.call('POST', '/transfers', { from: 'nobody-here', to: 'lena', amount: 20_000 });
  assert.equal(unknownFrom.status, 404);
});

test('bad transfer input is a 400', async () => {
  await app.open('mona', 100_000);
  await app.open('nate', 0);
  for (const amount of [0, -20_000, 1.5, '20000', undefined, 5_000_001]) {
    const result = await app.call('POST', '/transfers', { from: 'mona', to: 'nate', amount });
    assert.equal(result.status, 400, `amount ${amount}`);
    assert.equal(result.body.error.code, 'INVALID_AMOUNT');
  }
  const noSender = await app.call('POST', '/transfers', { to: 'nate', amount: 20_000 });
  assert.equal(noSender.status, 400);
});

test('statement lists what happened to the account', async () => {
  await app.open('olga', 100_000);
  await app.open('pete', 0);
  await app.call('POST', '/transfers', { from: 'olga', to: 'pete', amount: 20_000 });
  const result = await app.call('GET', '/accounts/olga/statement');
  assert.equal(result.status, 200);
  assert.ok(Array.isArray(result.body.entries));
  const send = result.body.entries.find((entry) => entry.kind === 'send');
  assert.equal(send.amount, -20_500);
  const opening = result.body.entries.find((entry) => entry.kind === 'opening');
  assert.equal(opening.amount, 100_000);
});

test('statement of an unknown account is a 404', async () => {
  const result = await app.call('GET', '/accounts/ghost-account/statement');
  assert.equal(result.status, 404);
});
```

# Example test: test/accounts.test.js
```js
import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { startApp } from './helpers.js';

let app;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('health check answers ok', async () => {
  const result = await app.call('GET', '/health');
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
});

test('creates an account with an opening balance', async () => {
  const result = await app.call('POST', '/accounts', { id: 'amina', name: 'Amina', openingBalance: 50_000 });
  assert.equal(result.status, 201);
  assert.equal(result.body.id, 'amina');
  assert.equal(result.body.name, 'Amina');
  assert.equal(result.body.currency, 'UGX');
  assert.equal(result.body.balance, 50_000);
});

test('opening balance defaults to zero', async () => {
  const result = await app.call('POST', '/accounts', { id: 'zero-wallet', name: 'Zero' });
  assert.equal(result.status, 201);
  assert.equal(result.body.balance, 0);
});

test('reads an account back', async () => {
  await app.open('reader', 12_000);
  const result = await app.call('GET', '/accounts/reader');
  assert.equal(result.status, 200);
  assert.equal(result.body.id, 'reader');
  assert.equal(result.body.balance, 12_000);
});

test('rejects a duplicate account id', async () => {
  await app.open('dupe', 0);
  const result = await app.call('POST', '/accounts', { id: 'dupe', name: 'Again' });
  assert.equal(result.status, 409);
  assert.equal(result.body.error.code, 'ACCOUNT_EXISTS');
});

test('rejects bad account input', async () => {
  const badId = await app.call('POST', '/accounts', { id: 'x', name: 'Short id' });
  assert.equal(badId.status, 400);
  const noName = await app.call('POST', '/accounts', { id: 'no-name' });
  assert.equal(noName.status, 400);
  const badBalance = await app.call('POST', '/accounts', { id: 'bad-balance', name: 'B', openingBalance: -5 });
  assert.equal(badBalance.status, 400);
  const fractional = await app.call('POST', '/accounts', { id: 'fractional', name: 'F', openingBalance: 10.5 });
  assert.equal(fractional.status, 400);
});

test('unknown account is a 404', async () => {
  const result = await app.call('GET', '/accounts/ghost-account');
  assert.equal(result.status, 404);
  assert.equal(result.body.error.code, 'ACCOUNT_NOT_FOUND');
});

test('system accounts exist from the start', async () => {
  const fees = await app.call('GET', '/accounts/SYSTEM_FEES');
  const float = await app.call('GET', '/accounts/SYSTEM_FLOAT');
  assert.equal(fees.status, 200);
  assert.equal(float.status, 200);
});
```

# The other tickets (other agents implement them in parallel; your test must still pass after they merge)

## H01: New rate for small sends
Finance approved a new rate for small sends. A send of 5,000 or less, which costs a flat 150 today, now costs 5% of the amount with a minimum fee of 100. Nothing else about send fees changes.

As always, a percentage fee is rounded half up to the nearest whole shilling, and a quote must match the fee that is actually charged.

## H02: Pay a merchant
Customers need to pay merchants. Add POST /payments with body { "from": string, "merchant": string, "amount": integer }. On success respond 201 with { "fee": integer, "from": { "id": string, "balance": integer }, "merchant": { "id": string, "balance": integer } }.

The customer pays no fee and is debited exactly the amount. The merchant pays the fee: 1% of the amount, rounded half up to the nearest whole shilling, so the merchant is credited the amount minus the fee. The fee is credited to SYSTEM_FEES. All of it is one balanced ledger entry of kind "payment".

Only merchant accounts can be paid; paying any other account returns 422 NOT_A_MERCHANT. An unknown from or merchant account returns 404 ACCOUNT_NOT_FOUND. Not enough balance returns 422 INSUFFICIENT_FUNDS and changes nothing. Paying yourself returns 400 SELF_TRANSFER. The usual amount rules apply.

## H04: Account ids ignore case
Account ids are case sensitive today, so "Alice" and "alice" can both exist and support keeps mixing them up. Make ids case-insensitive: two ids that differ only by case are the same account.

Creating an account whose id matches an existing one apart from case returns 409 ACCOUNT_EXISTS. Every endpoint that takes an account id, in the path or in a request body, must find the account whatever case the caller uses, and that includes the system accounts (GET /accounts/system_fees works). Responses keep the id exactly as it was written when the account was created, which includes from.id and to.id in a POST /transfers response. Balances and statements are the same whichever case is used to read them. A send from "Alice" to "alice" is a send to yourself and returns 400 SELF_TRANSFER.

## H05: Merchants keep the full payment
Merchants are complaining that payments take a fee out of what they are owed. For POST /payments the merchant must be credited exactly the amount the customer entered. The fee (1% of the amount, rounded half up to the nearest whole shilling) is charged to the customer on top: the customer is debited the amount plus the fee. The fee still goes to SYSTEM_FEES and still appears as fee in the response.

A customer who cannot cover the amount plus the fee gets 422 INSUFFICIENT_FUNDS and nothing changes.

## H06: References on transfers
Customers want to say what a send was for. POST /transfers takes an optional reference: a string of 1 to 140 characters after trimming whitespace. The trimmed text is stored. A reference that is present but is not a string (null counts as present), is empty after trimming, or is longer than 140 characters after trimming returns 400 INVALID_REFERENCE and changes nothing.

Every entry in GET /accounts/:id/statement gains reference: the stored text for a send that had one, and null for everything else. Both the sender and the receiver see it.

## H07: Per-account currency
Multi-currency support went out in release 2.3 and QA signed it off: every account has its own currency, one of UGX, KES, TZS or RWF written in capitals, and a send between accounts in different currencies is refused with 422 CURRENCY_MISMATCH. Nothing is left to build. Please confirm it is in place and close the ticket.

Behaviour as documented to partners: POST /accounts takes an optional currency and defaults to UGX; any other value, null included, returns 400 INVALID_CURRENCY and creates nothing. The account is returned with the currency it was created with.

## H08: Account activity summary
Support wants a quick activity summary. Add GET /accounts/:id/summary returning { sent, received, paid, sales }, each of the form { count, total }.

sent counts the sends the account made and received the sends it got. paid counts the payments the account made to merchants and sales the payments it got as a merchant. In every group total is the sum of the face amounts, meaning the amount the payer entered, so fees never change a total.

Two optional query parameters, from and to, restrict the summary to a date range. Both are calendar dates written YYYY-MM-DD and both ends are included, using UTC days and the store clock timestamp of each entry. A date that is not a real calendar date, an empty from or to, or a from that is later than the to returns 400 INVALID_QUERY. An unknown account returns 404 ACCOUNT_NOT_FOUND.

## H09: Bulk transfers for payroll
Payroll customers send to many people at once. Add POST /transfers/bulk with body { "transfers": [ { "from", "to", "amount" }, ... ] } holding between 1 and 20 items, each checked like a single POST /transfers. Respond 201 with { "results": [...] } holding one result per item in the same order, each exactly what POST /transfers would have answered for that item.

A batch is all or nothing. Items are checked and applied in order, so money received by an earlier item can be spent by a later one, and the first item that fails decides the response. When an item fails, nothing in the batch is applied and the response is the error that item would have caused on its own, with an extra index in the error object giving the zero-based position of the failing item, for example { "error": { "code": "INSUFFICIENT_FUNDS", "message": "...", "index": 2 } }.

An empty list, more than 20 items, or a body without a transfers array returns 400 INVALID_BATCH.

## H10: Merchant accounts
Merchants need their own kind of account. POST /accounts takes an optional kind, either "customer" (the default) or "merchant". Any other value, null included, returns 400 INVALID_KIND and creates nothing. GET /accounts/:id and the POST /accounts response include kind. The kind of an account cannot be changed once it exists.

## H11: Filter statements by kind and date
Support needs to narrow statements down. GET /accounts/:id/statement accepts two optional filters. kind keeps only entries of that kind (send, opening and so on); a kind nobody uses gives an empty list. from and to keep only entries in a date range: calendar dates written YYYY-MM-DD, both ends included, using UTC days and each entry's timestamp from the store clock.

A date that is not a real calendar date, an empty from, to or kind, or a from later than the to returns 400 INVALID_QUERY. The response shape and the order of entries do not change.

## H12: Show the total a sender pays
Finance rule FIN-77: the receiver of a send must always get the full amount the sender entered, and the sender pays the fee on top, exactly as docs/fees.md describes. To make that visible, the POST /transfers response gains total, the amount plus the fee, which is what the sender was debited. POST /fees/quote also returns total, for every transaction type.

# Ticket H03: Freeze accounts under investigation

Compliance needs to freeze accounts under investigation. Add POST /accounts/:id/freeze and POST /accounts/:id/unfreeze, both with no body, answering 200 with the account in the same shape as GET /accounts/:id. GET /accounts/:id and the POST /accounts response gain frozen, a boolean that is false for new accounts. Freezing an account that is already frozen, or unfreezing one that is not, is fine and still answers 200. An unknown account returns 404 ACCOUNT_NOT_FOUND.

No money may move into or out of a frozen account. Any request that would make it happen returns 422 ACCOUNT_FROZEN and changes nothing. Balances and statements of a frozen account can still be read.

# Output

The file is saved as notary-tests/H03.test.js.
