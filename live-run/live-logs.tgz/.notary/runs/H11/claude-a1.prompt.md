You are fixing one ticket in a small Node.js codebase (ES modules, no dependencies).
Rules:
- You may edit only files under src/ and docs/.
- Never touch test/, acceptance/, notary-tests/, scripts/, backlog/, package.json or tests.lock.json.
- Do not add dependencies. Node standard library only.
- Do not run git.
- Keep `npm test` (the regression suite) green.

# Repository

--- AGENTS.md ---
# Notes for coding agents working in this repository

This is a small mobile money fee and ledger API in plain Node (ES modules, no dependencies).

- Run the regression suite with `npm test`. It must stay green.
- Run one task's acceptance tests with `node --test acceptance/T01.test.js` (swap the id). Run `npm run grade` for everything.
- Do not edit anything under `test/` or `acceptance/`, `backlog/backlog.json` or `scripts/`. `npm run verify:tests` fails if you do, and the fix is to restore the files, never to regenerate `tests.lock.json`.
- Do not add dependencies. Node 20 or newer, standard library only.
- Money is always a whole number of UGX. Never use floating point for stored amounts.
- Every movement of money goes through `store.ledger.post` as one balanced entry.
- `docs/api.md` describes the endpoints and error codes that exist today. Follow the same response and error shapes in new code.
- Errors are created in `src/errors.js` and thrown as `AppError`. The server turns them into JSON responses.
--- docs/api.md ---
# API as it stands today

All bodies are JSON. Money is a whole number of UGX. Errors look like `{ "error": { "code": "...", "message": "..." } }`.

| Method and path                  | What it does                                                          |
| -------------------------------- | --------------------------------------------------------------------- |
| `GET /health`                    | Answers `{ "ok": true }`.                                             |
| `POST /accounts`                 | Creates a wallet from `{ id, name, openingBalance? }`. Answers 201.   |
| `GET /accounts/:id`              | Returns `{ id, name, currency, balance, frozen }`.                    |
| `GET /accounts/:id/statement`    | Returns `{ entries }`, oldest first. Each entry is `{ seq, kind, memo, at, amount }`, where `amount` is the net change for that account. |
| `POST /accounts/:id/freeze`      | No body. Marks the account frozen. Answers 200 with the account, same shape as `GET /accounts/:id`. Freezing an already-frozen account still answers 200. |
| `POST /accounts/:id/unfreeze`    | No body. Clears the frozen flag. Answers 200 with the account. Unfreezing an account that isn't frozen still answers 200. |
| `POST /fees/quote`               | Takes `{ type, amount }` and returns `{ type, amount, fee }`.         |
| `POST /transfers`                | Sends `{ from, to, amount }`. The sender pays the fee on top. Answers 201 with `{ fee, from: { id, balance }, to: { id, balance } }`. |

`POST /transfers` honours an `Idempotency-Key` header: a repeat of the same request with the same key returns the first response and moves no money.

`POST /accounts` and `GET /accounts/:id` include `frozen`, a boolean that is `false` for new accounts. No money may move into or out of a frozen account; a transfer touching a frozen account answers 422 `ACCOUNT_FROZEN` and changes nothing. Balances and statements of a frozen account can still be read.

`SYSTEM_FEES` and `SYSTEM_FLOAT` are real accounts. They can be read with `GET /accounts/:id` and `GET /accounts/:id/statement` like any wallet.

## Error codes in use

| Code                 | Status | Meaning                                              |
| -------------------- | ------ | ---------------------------------------------------- |
| `INVALID_JSON`       | 400    | The body is not valid JSON.                          |
| `INVALID_BODY`       | 400    | The body is missing a field or has the wrong shape.  |
| `INVALID_AMOUNT`     | 400    | Not a positive whole number up to 5,000,000.         |
| `INVALID_TYPE`       | 400    | Unknown transaction type for a quote.                |
| `SELF_TRANSFER`      | 400    | Sender and receiver are the same account.            |
| `NOT_FOUND`          | 404    | No such route.                                       |
| `ACCOUNT_NOT_FOUND`  | 404    | No such account.                                     |
| `ACCOUNT_EXISTS`     | 409    | The account id is taken.                             |
| `INSUFFICIENT_FUNDS` | 422    | The balance cannot cover the amount plus charges.    |
| `ACCOUNT_FROZEN`     | 422    | The transfer touches a frozen account.               |

## Ledger

Every movement of money is one entry in a double-entry journal. Debits equal credits in every entry. A wallet's balance is its credits minus its debits, so `SYSTEM_FLOAT` goes negative as wallets are funded, and the balances of all accounts in the store add up to zero.

The store takes a clock function, which the tests replace with a fake so that dates are predictable.
--- docs/fees.md ---
# Fee schedule

The schedule lives in `src/fees/schedule.js`. Amounts are whole Ugandan shillings (UGX). A band applies when the amount is at or below its upper limit and above the previous band's limit.

## Send

| Amount up to | Fee            |
| ------------ | -------------- |
| 5,000        | 150 flat       |
| 50,000       | 500 flat       |
| 500,000      | 1% of amount   |
| 5,000,000    | 0.8% of amount |

The sender pays the fee on top of the amount. The fee is credited to `SYSTEM_FEES`.

The rates in this repository are made up for the exercise. They are not the rates of any real operator or tax authority.
--- docs/limits.md ---
# Daily send limits (compliance policy CP-7)

The limit is the most a single account may send in one UTC day. It is set by the account's KYC tier.

| KYC tier | Daily send limit (UGX) |
| -------- | ---------------------- |
| tier1    | 500,000                |
| tier2    | 2,000,000              |
| tier3    | 5,000,000              |

Accounts with no verification on file are treated as tier1.
--- src/accounts.js ---
import { DEFAULT_CURRENCY, SYSTEM_ACCOUNTS } from './config.js';
import { accountExists, accountNotFound } from './errors.js';

export function requireAccount(store, id) {
  const normalizedId = id.toLowerCase();
  for (const account of store.accounts.values()) {
    if (account.id.toLowerCase() === normalizedId) return account;
  }
  throw accountNotFound(id);
}

export function accountView(store, account) {
  return {
    id: account.id,
    name: account.name,
    currency: account.currency,
    balance: store.ledger.balance(account.id),
    frozen: Boolean(account.frozen),
  };
}

export function setFrozen(store, id, frozen) {
  const account = requireAccount(store, id);
  account.frozen = frozen;
  return accountView(store, account);
}

export function createAccount(store, { id, name, openingBalance, kind, currency }) {
  const normalizedId = id.toLowerCase();
  for (const account of store.accounts.values()) {
    if (account.id.toLowerCase() === normalizedId) throw accountExists(id);
  }
  const account = {
    id,
    name,
    currency: currency ?? DEFAULT_CURRENCY,
    frozen: false,
    // store optional kind (e.g., 'merchant') for later checks
    ...(kind ? { kind } : {}),
  };
  store.accounts.set(id, account);
  if (openingBalance > 0) {
    store.ledger.post({
      kind: 'opening',
      memo: `opening balance for ${id}`,
      lines: [
        { account: SYSTEM_ACCOUNTS.float, debit: openingBalance },
        { account: id, credit: openingBalance },
      ],
    });
  }
  return accountView(store, account);
}
--- src/api/idempotency.js ---
const seen = new Map();

export function recall(key) {
  return key === undefined ? undefined : seen.get(key);
}

export function remember(key, response) {
  if (key !== undefined) seen.set(key, response);
}
--- src/api/routes.js ---
import { accountView, createAccount, requireAccount, setFrozen } from '../accounts.js';
import { SCHEDULE } from '../fees/schedule.js';
import { sendMoney } from '../ledger/transfer.js';
import { payMerchant } from '../ledger/payment.js';
import { validateNewAccount, validateQuote, validateTransfer, validatePayment, validateSummaryQuery } from '../validation.js';
import { recall, remember } from './idempotency.js';

const reply = (status, body) => ({ status, body });

function quoteFee(type, amount) {
  const band = SCHEDULE[type].find((candidate) => amount <= candidate.upTo);
  if (band.flat !== undefined) return band.flat;
  return Math.floor((amount * band.percent) / 100);
}

function postTransfer({ store, body, headers }) {
  const input = validateTransfer(body);
  const key = headers['Idempotency-Key'];
  const cached = recall(key);
  if (cached) return cached;
  const response = reply(201, sendMoney(store, input));
  remember(key, response);
  return response;
}

function postPayment({ store, body }) {
  const input = validatePayment(body);
  const result = payMerchant(store, input);
  return reply(201, result);
}

function getSummary({ store, params, query }) {
  const account = requireAccount(store, params.id);
  const { from, to } = validateSummaryQuery(query);
  const entries = store.ledger.statementFor(account.id);
  
  const filtered = entries.filter((e) => {
    const d = e.at.split('T')[0];
    if (from && d < from) return false;
    if (to && d > to) return false;
    return true;
  });

  const res = {
    sent: { count: 0, total: 0 },
    received: { count: 0, total: 0 },
    paid: { count: 0, total: 0 },
    sales: { count: 0, total: 0 },
  };

  for (const e of filtered) {
    if (e.kind === 'send') {
      // The statement amount includes the fee for the sender, so we extract the face amount.
      // Fee is calculated using the same schedule as in transfer.js.
      const fee = SCHEDULE['send'].find((c) => Math.abs(e.amount) <= c.upTo + (c.flat || c.upTo * (c.percent / 100)))?.flat || 0; // Simplified estimation check
      // Actually, easier: since send entries are simple, look at the debit/credit lines.
      // But we only have statement lines here. Re-calculating face amount from net change:
      // Sender: debit = face + fee. Net change = -(face + fee).
      // Receiver: credit = face. Net change = +face.
      
      if (e.amount < 0) {
        res.sent.count++;
        // Recover face amount: amount is -(face + fee).
        // Since we don't have fee easily, let's use the actual transaction lines.
        const entry = store.ledger.entries.find(item => item.seq === e.seq);
        const debit = entry.lines.find(l => l.account.toLowerCase() === account.id.toLowerCase()).debit;
        const credit = entry.lines.find(l => l.account.toLowerCase() !== account.id.toLowerCase() && l.credit > 0)?.credit || 0;
        res.sent.total += credit;
      } else {
        res.received.count++;
        res.received.total += e.amount;
      }
    } else if (e.kind === 'payment') {
      if (e.amount < 0) {
        res.paid.count++;
        res.paid.total += Math.abs(e.amount);
      } else {
        res.sales.count++;
        res.sales.total += e.amount;
      }
    }
  }
  return reply(200, res);
}

export const routes = [
  {
    method: 'GET',
    path: '/health',
    handler: () => reply(200, { ok: true }),
  },
  {
    method: 'POST',
    path: '/accounts',
    handler: ({ store, body }) => reply(201, createAccount(store, validateNewAccount(body))),
  },
  {
    method: 'GET',
    path: '/accounts/:id',
    handler: ({ store, params }) => reply(200, accountView(store, requireAccount(store, params.id))),
  },
  {
    method: 'GET',
    path: '/accounts/:id/statement',
    handler: ({ store, params }) => {
      requireAccount(store, params.id);
      return reply(200, { entries: store.ledger.statementFor(params.id) });
    },
  },
  {
    method: 'GET',
    path: '/accounts/:id/summary',
    handler: getSummary,
  },
  {
    method: 'POST',
    path: '/fees/quote',
    handler: ({ body }) => {
      const { type, amount } = validateQuote(body);
      return reply(200, { type, amount, fee: quoteFee(type, amount) });
    },
  },
  {
    method: 'POST',
    path: '/transfers',
    handler: postTransfer,
  },
  {
    method: 'POST',
    path: '/payments',
    handler: postPayment,
  },
  {
    method: 'POST',
    path: '/accounts/:id/freeze',
    handler: ({ store, params }) => reply(200, setFrozen(store, params.id, true)),
  },
  {
    method: 'POST',
    path: '/accounts/:id/unfreeze',
    handler: ({ store, params }) => reply(200, setFrozen(store, params.id, false)),
  },
];
--- src/api/server.js ---
import http from 'node:http';
import { AppError, invalidJson, routeNotFound } from '../errors.js';
import { createStore } from '../store.js';
import { routes } from './routes.js';

const PARAM_PATTERN = /:([a-z]+)/g;

const compiled = routes.map((route) => {
  const names = [];
  const source = route.path.replace(PARAM_PATTERN, (_, name) => {
    names.push(name);
    return '([^/]+)';
  });
  return { route, names, regex: new RegExp(`^${source}$`) };
});

function findRoute(method, pathname) {
  for (const { route, names, regex } of compiled) {
    const match = route.method === method && regex.exec(pathname);
    if (match) {
      return { route, params: Object.fromEntries(names.map((name, index) => [name, match[index + 1]])) };
    }
  }
  return null;
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (chunks.length === 0) return undefined;
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw invalidJson();
  }
}

function send(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(body));
}

export function createApp(store = createStore()) {
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const found = findRoute(req.method, url.pathname);
      if (!found) throw routeNotFound();
      const body = await readJson(req);
      const result = await found.route.handler({
        store,
        params: found.params,
        query: url.searchParams,
        body,
        headers: req.headers,
      });
      send(res, result.status, result.body);
    } catch (error) {
      if (error instanceof AppError) {
        send(res, error.status, { error: { code: error.code, message: error.message } });
        return;
      }
      console.error(error);
      send(res, 500, { error: { code: 'INTERNAL', message: 'internal error' } });
    }
  });
  return { server, store };
}
--- src/config.js ---
export const DEFAULT_CURRENCY = 'UGX';
export const MAX_AMOUNT = 5_000_000;
export const ACCOUNT_ID_PATTERN = /^[A-Za-z0-9_-]{3,32}$/;

export const SYSTEM_ACCOUNTS = {
  fees: 'SYSTEM_FEES',
  float: 'SYSTEM_FLOAT',
};
--- src/errors.js ---
export class AppError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export const invalidJson = () => new AppError(400, 'INVALID_JSON', 'request body is not valid JSON');
export const invalidBody = (message) => new AppError(400, 'INVALID_BODY', message);
export const invalidQuery = () => new AppError(400, 'INVALID_QUERY', 'invalid date range query');
export const invalidReference = () => new AppError(400, 'INVALID_REFERENCE', 'reference must be a string of 1 to 140 characters');
export const invalidAmount = () =>
  new AppError(400, 'INVALID_AMOUNT', 'amount must be a positive whole number within the allowed maximum');
export const invalidType = () => new AppError(400, 'INVALID_TYPE', 'unknown transaction type');
export const selfTransfer = () => new AppError(400, 'SELF_TRANSFER', 'sender and receiver must differ');
export const routeNotFound = () => new AppError(404, 'NOT_FOUND', 'no such route');
export const accountNotFound = (id) => new AppError(404, 'ACCOUNT_NOT_FOUND', `account ${id} not found`);
export const accountExists = (id) => new AppError(409, 'ACCOUNT_EXISTS', `account ${id} already exists`);
export const insufficientFunds = () =>
  new AppError(422, 'INSUFFICIENT_FUNDS', 'balance is too low for the amount plus charges');
export const notAMerchant = () => new AppError(422, 'NOT_A_MERCHANT', 'account is not a merchant');
export const accountFrozen = (id) => new AppError(422, 'ACCOUNT_FROZEN', `account ${id} is frozen`);
export const invalidCurrency = () =>
  new AppError(400, 'INVALID_CURRENCY', 'unsupported currency');
export const currencyMismatch = () =>
  new AppError(422, 'CURRENCY_MISMATCH', 'cannot transfer between accounts of different currencies');
--- src/fees/calculate.js ---
import { SCHEDULE } from './schedule.js';

export function calculateFee(type, amount) {
  const bands = SCHEDULE[type];
  if (!bands) throw new Error(`no fee schedule for ${type}`);
  const band = bands.find((candidate) => amount <= candidate.upTo);
  if (!band) throw new Error(`amount ${amount} is above the top fee band for ${type}`);
  if (band.flat !== undefined) return band.flat;
  if (band.min !== undefined) {
    return Math.max(Math.round((amount * band.percent) / 100), band.min);
  }
  return Math.floor((amount * band.percent) / 100);
}
--- src/fees/schedule.js ---
export const SCHEDULE = {
  send: [
    { upTo: 5_000, percent: 5, min: 100 },
    { upTo: 50_000, flat: 500 },
    { upTo: 500_000, percent: 1 },
    { upTo: 5_000_000, percent: 0.8 },
  ],
};
--- src/index.js ---
import { createApp } from './api/server.js';

const port = Number(process.env.PORT ?? 3000);
const { server } = createApp();
server.listen(port, () => {
  console.log(`ledger api listening on http://localhost:${port}`);
});
--- src/ledger/ledger.js ---
// Balances are credits minus debits, so SYSTEM_FLOAT goes negative as wallets are funded
// and every account in the store always sums to zero.
export function createLedger(clock) {
  const entries = [];

  function post({ kind, memo, lines, reference = null }) {
    const normalized = lines.map(({ account, debit = 0, credit = 0 }) => ({ account, debit, credit }));
    const debits = normalized.reduce((sum, line) => sum + line.debit, 0);
    const credits = normalized.reduce((sum, line) => sum + line.credit, 0);
    if (debits !== credits) {
      throw new Error(`unbalanced ledger entry: debits ${debits}, credits ${credits}`);
    }
    const entry = { seq: entries.length + 1, kind, memo, at: clock().toISOString(), lines: normalized, reference };
    entries.push(entry);
    return entry;
  }

  function balance(accountId) {
    const lowerId = accountId.toLowerCase();
    return entries
      .flatMap((entry) => entry.lines)
      .filter((line) => line.account.toLowerCase() === lowerId)
      .reduce((sum, line) => sum + line.credit - line.debit, 0);
  }

  function statementFor(accountId) {
    const lowerId = accountId.toLowerCase();
    return entries
      .filter((entry) => entry.lines.some((line) => line.account.toLowerCase() === lowerId))
      .map((entry) => ({
        seq: entry.seq,
        kind: entry.kind,
        memo: entry.memo,
        at: entry.at,
        amount: entry.lines
          .filter((line) => line.account.toLowerCase() === lowerId)
          .reduce((sum, line) => sum + line.credit - line.debit, 0),
        reference: entry.reference ?? null,
      }));
  }

  return { post, balance, statementFor, entries };
}
--- src/ledger/payment.js ---
import { requireAccount } from '../accounts.js';
import { SYSTEM_ACCOUNTS } from '../config.js';
import { insufficientFunds, selfTransfer, notAMerchant } from '../errors.js';

/**
 * Process a merchant payment.
 *
 * Customer (from) is debited the amount plus a fee, where fee = round(1% of amount) (half‑up).
 * Merchant is credited the full amount entered, with no fee taken out.
 * Fee is credited to SYSTEM_FEES.
 *
 * Throws:
 *   - selfTransfer()   if from === merchant
 *   - accountNotFound   via requireAccount if either party missing
 *   - notAMerchant()    if merchant account is not marked as a merchant
 *   - insufficientFunds() if from's balance < amount + fee
 */
export function payMerchant(store, { from, merchant, amount }) {
  if (from === merchant) throw selfTransfer();

  // ensure both accounts exist
  const fromAcc = requireAccount(store, from);
  const merchantAcc = requireAccount(store, merchant);

  // merchant must be flagged as a merchant (kind === 'merchant'), or its id
  // identifies it as one (accounts opened without an explicit kind but whose
  // id names them as a merchant are still payable)
  const isMerchant = merchantAcc.kind === 'merchant' || /merchant/i.test(merchantAcc.id);
  if (!isMerchant) throw notAMerchant();

  const { ledger } = store;

  // fee calculation: 1% rounded half‑up
  const fee = Math.round(amount * 0.01);

  // customer pays amount plus fee on top; merchant keeps the full amount
  if (ledger.balance(from) < amount + fee) throw insufficientFunds();

  const lines = [
    { account: from, debit: amount + fee },
    { account: merchant, credit: amount },
  ];
  if (fee > 0) {
    lines.push({ account: SYSTEM_ACCOUNTS.fees, credit: fee });
  }

  ledger.post({ kind: 'payment', memo: `payment from ${from} to ${merchant}`, lines });

  return {
    fee,
    from: { id: from, balance: ledger.balance(from) },
    merchant: { id: merchant, balance: ledger.balance(merchant) },
  };
}
--- src/ledger/transfer.js ---
import { requireAccount } from '../accounts.js';
import { SYSTEM_ACCOUNTS } from '../config.js';
import { accountFrozen, insufficientFunds, selfTransfer, currencyMismatch } from '../errors.js';
import { calculateFee } from '../fees/calculate.js';

export function sendMoney(store, { from, to, amount, reference }) {
  if (from.toLowerCase() === to.toLowerCase()) throw selfTransfer();
  const fromAcc = requireAccount(store, from);
  const toAcc = requireAccount(store, to);
  if (fromAcc.frozen) throw accountFrozen(from);
  if (toAcc.frozen) throw accountFrozen(to);
  // currency check
  if (fromAcc.currency !== toAcc.currency) throw currencyMismatch();
  const { ledger } = store;
  const fee = calculateFee('send', amount);
  if (ledger.balance(fromAcc.id) < amount + fee) throw insufficientFunds();

  const lines = [
    { account: fromAcc.id, debit: amount + fee },
    { account: toAcc.id, credit: amount },
  ];
  if (fee > 0) lines.push({ account: SYSTEM_ACCOUNTS.fees, credit: fee });
  ledger.post({ kind: 'send', memo: `send ${fromAcc.id} to ${toAcc.id}`, lines, reference });

  return {
    fee,
    from: { id: fromAcc.id, balance: ledger.balance(fromAcc.id) },
    to: { id: toAcc.id, balance: ledger.balance(toAcc.id) },
  };
}
--- src/store.js ---
import { DEFAULT_CURRENCY, SYSTEM_ACCOUNTS } from './config.js';
import { createLedger } from './ledger/ledger.js';

export function createStore({ clock = () => new Date() } = {}) {
  const accounts = new Map();
  for (const id of Object.values(SYSTEM_ACCOUNTS)) {
    accounts.set(id, { id, name: id, currency: DEFAULT_CURRENCY, system: true });
  }
  return { accounts, ledger: createLedger(clock), clock };
}
--- src/validation.js ---
import { ACCOUNT_ID_PATTERN, MAX_AMOUNT } from './config.js';
import { invalidAmount, invalidBody, invalidType, invalidReference, invalidCurrency, invalidQuery } from './errors.js';

const QUOTE_TYPES = ['send'];
const SUPPORTED_CURRENCIES = ['UGX', 'KES', 'TZS', 'RWF'];

export function requireObject(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    throw invalidBody('body must be a JSON object');
  }
  return body;
}

export function requireAmount(value) {
  if (!Number.isInteger(value) || value <= 0 || value > MAX_AMOUNT) throw invalidAmount();
  return value;
}

export function requireAccountId(value, field) {
  if (typeof value !== 'string' || !ACCOUNT_ID_PATTERN.test(value)) {
    throw invalidBody(`${field} must be a valid account id`);
  }
  return value;
}

export function validateNewAccount(body) {
  const { id, name, openingBalance = 0, kind, currency } = requireObject(body);
  requireAccountId(id, 'id');
  if (typeof name !== 'string' || name.trim() === '') throw invalidBody('name is required');
  if (!Number.isInteger(openingBalance) || openingBalance < 0) {
    throw invalidBody('openingBalance must be a non-negative whole number');
  }
  // currency validation
  let finalCurrency = 'UGX';
  if (currency !== undefined) {
    if (typeof currency !== 'string' || !SUPPORTED_CURRENCIES.includes(currency)) {
      throw invalidCurrency();
    }
    finalCurrency = currency;
  } else {
    // If currency is missing, default is UGX. 
    // If present but null/invalid, the check above throws.
    finalCurrency = 'UGX';
  }
  // kind is optional; keep as‑is for creator to use (e.g., 'merchant')
  return { id, name: name.trim(), openingBalance, kind, currency: finalCurrency };
}

export function validateTransfer(body) {
  const { from, to, amount, reference } = requireObject(body);
  let validatedRef = null;
  if (reference !== undefined) {
    if (typeof reference !== 'string') throw invalidReference();
    const trimmed = reference.trim();
    if (trimmed.length === 0 || trimmed.length > 140) throw invalidReference();
    validatedRef = trimmed;
  }
  return {
    from: requireAccountId(from, 'from'),
    to: requireAccountId(to, 'to'),
    amount: requireAmount(amount),
    reference: validatedRef,
  };
}

export function validateQuote(body) {
  const { type, amount } = requireObject(body);
  if (!QUOTE_TYPES.includes(type)) throw invalidType();
  return { type, amount: requireAmount(amount) };
}

export function validatePayment(body) {
  const { from, merchant, amount } = requireObject(body);
  return {
    from: requireAccountId(from, 'from'),
    merchant: requireAccountId(merchant, 'merchant'),
    amount: requireAmount(amount),
  };
}

function isValidDate(d) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return false;
  const [y, m, day] = d.split('-').map(Number);
  const date = new Date(y, m - 1, day);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === day;
}

export function validateSummaryQuery(query) {
  const from = query.get('from');
  const to = query.get('to');
  if ((from !== null && !isValidDate(from)) || (to !== null && !isValidDate(to))) throw invalidQuery();
  if (from !== null && to !== null && from > to) throw invalidQuery();
  return { from, to };
}

# Ticket H11: Filter statements by kind and date

Support needs to narrow statements down. GET /accounts/:id/statement accepts two optional filters. kind keeps only entries of that kind (send, opening and so on); a kind nobody uses gives an empty list. from and to keep only entries in a date range: calendar dates written YYYY-MM-DD, both ends included, using UTC days and each entry's timestamp from the store clock.

A date that is not a real calendar date, an empty from, to or kind, or a from later than the to returns 400 INVALID_QUERY. The response shape and the order of entries do not change.

# Acceptance test

This locked test must pass: notary-tests/H11.test.js

```js
import assert from 'node:assert/strict';
import { before, after, test } from 'node:test';
import { startApp, fakeClock } from '../test/helpers.js';

let app;
before(async () => {
  // deterministic clock so we can query by calendar dates
  const clock = fakeClock('2026-01-15T00:00:00.000Z');
  app = await startApp({ clock });
});
after(async () => {
  await app.close();
});

test('kind filter returns only matching entries', async () => {
  // setup two accounts and a send
  await app.open('alice', 10_000);
  await app.open('bob', 0);
  await app.call('POST', '/transfers', { from: 'alice', to: 'bob', amount: 5_000 });

  // opening entries only
  const openingRes = await app.call('GET', '/accounts/alice/statement?kind=opening');
  assert.equal(openingRes.status, 200);
  assert.ok(Array.isArray(openingRes.body.entries));
  // expect exactly one opening entry (the account creation)
  // 1 opening entry = 1
  assert.equal(openingRes.body.entries.length, 1);
  assert.equal(openingRes.body.entries[0].kind, 'opening');

  // send entries only
  const sendRes = await app.call('GET', '/accounts/alice/statement?kind=send');
  assert.equal(sendRes.status, 200);
  assert.ok(Array.isArray(sendRes.body.entries));
  // expect exactly one send entry (the transfer we performed)
  // 1 send entry = 1
  assert.equal(sendRes.body.entries.length, 1);
  assert.equal(sendRes.body.entries[0].kind, 'send');

  // unknown kind yields empty list
  const noneRes = await app.call('GET', '/accounts/alice/statement?kind=unknownkind');
  assert.equal(noneRes.status, 200);
  assert.ok(Array.isArray(noneRes.body.entries));
  // unknown kind produces no entries
  // 0 entries = 0
  assert.equal(noneRes.body.entries.length, 0);
});

test('date range filter keeps entries within inclusive UTC dates', async () => {
  // fresh accounts with controlled timestamps
  await app.open('carol', 20_000); // opening at 2026-01-15
  // advance one day for the next operation
  app.store.clock.advanceDays(1); // now 2026-01-16
  await app.open('dave', 0);
  await app.call('POST', '/transfers', { from: 'carol', to: 'dave', amount: 5_000 });

  // only opening (2026-01-15)
  const day0Res = await app.call('GET',
    '/accounts/carol/statement?from=2026-01-15&to=2026-01-15');
  assert.equal(day0Res.status, 200);
  assert.ok(Array.isArray(day0Res.body.entries));
  // expect 1 entry: the opening on 2026-01-15
  // 1 opening entry = 1
  assert.equal(day0Res.body.entries.length, 1);
  assert.equal(day0Res.body.entries[0].kind, 'opening');

  // only send (2026-01-16)
  const day1Res = await app.call('GET',
    '/accounts/carol/statement?from=2026-01-16&to=2026-01-16');
  assert.equal(day1Res.status, 200);
  assert.ok(Array.isArray(day1Res.body.entries));
  // expect 1 entry: the send on 2026-01-16
  // 1 send entry = 1
  assert.equal(day1Res.body.entries.length, 1);
  assert.equal(day1Res.body.entries[0].kind, 'send');

  // both days
  const bothRes = await app.call('GET',
    '/accounts/carol/statement?from=2026-01-15&to=2026-01-16');
  assert.equal(bothRes.status, 200);
  assert.ok(Array.isArray(bothRes.body.entries));
  // expect 2 entries: opening + send
  // 1 opening + 1 send = 2
  assert.equal(bothRes.body.entries.length, 2);
  const kinds = bothRes.body.entries.map(e => e.kind).sort();
  assert.deepEqual(kinds, ['opening', 'send']);
});

test('invalid query parameters cause a 400-ish error', async () => {
  await app.open('eve', 10_000);
  // empty kind
  const emptyKind = await app.call('GET', '/accounts/eve/statement?kind=');
  assert.ok(emptyKind.status >= 400, 'empty kind should be rejected');

  // malformed date
  const badDate = await app.call('GET', '/accounts/eve/statement?from=2026-02-30&to=2026-03-01');
  assert.ok(badDate.status >= 400, 'invalid from date should be rejected');

  // empty from
  const emptyFrom = await app.call('GET', '/accounts/eve/statement?from=&to=2026-01-15');
  assert.ok(emptyFrom.status >= 400, 'empty from should be rejected');

  // from later than to
  const reversed = await app.call('GET', '/accounts/eve/statement?from=2026-01-20&to=2026-01-10');
  assert.ok(reversed.status >= 400, 'from later than to should be rejected');
});
```

# Output

Edit the files directly. Run `node --test notary-tests/H11.test.js` and `npm test` before finishing. Finish with one line saying what you changed.
